import {
  pgTable,
  serial,
  varchar,
  text,
  integer,
  boolean,
  timestamp,
  date,
  decimal,
  jsonb,
  numeric,
  doublePrecision,
} from "drizzle-orm/pg-core";

// ─────────────────────────────────────────────
// USERS & ROLES
// ─────────────────────────────────────────────

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).unique(),
  phone: varchar("phone", { length: 30 }),
  passwordHash: varchar("password_hash", { length: 255 }),
  role: varchar("role", { length: 30 }).default("patient").notNull(), // patient, doctor, admin, staff, pharmacist, lab
  avatarUrl: varchar("avatar_url", { length: 500 }),
  status: varchar("status", { length: 20 }).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// HOSPITALS / BRANCHES
// ─────────────────────────────────────────────

export const hospitals = pgTable("hospitals", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  code: varchar("code", { length: 30 }).unique(),
  address: text("address"),
  city: varchar("city", { length: 120 }),
  state: varchar("state", { length: 120 }),
  country: varchar("country", { length: 120 }).default("India"),
  phone: varchar("phone", { length: 30 }),
  email: varchar("email", { length: 255 }),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  operatingHours: text("operating_hours"),
  emergency24x7: boolean("emergency_24x7").default(true),
  beds: integer("beds").default(0),
  icuBeds: integer("icu_beds").default(0),
  accreditations: text("accreditations"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// DEPARTMENTS
// ─────────────────────────────────────────────

export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  code: varchar("code", { length: 50 }),
  description: text("description"),
  icon: varchar("icon", { length: 50 }),
  hospitalId: integer("hospital_id").references(() => hospitals.id),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// PATIENTS
// ─────────────────────────────────────────────

export const patients = pgTable("patients", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  medicalId: varchar("medical_id", { length: 100 }).unique(), // auto-generated UID
  bloodGroup: varchar("blood_group", { length: 10 }),
  dob: date("dob"),
  gender: varchar("gender", { length: 20 }),
  heightCm: doublePrecision("height_cm"),
  weightKg: doublePrecision("weight_kg"),
  allergies: text("allergies"), // comma-separated
  chronicConditions: text("chronic_conditions"),
  emergencyContactName: varchar("emergency_contact_name", { length: 255 }),
  emergencyContactPhone: varchar("emergency_contact_phone", { length: 30 }),
  insuranceProvider: varchar("insurance_provider", { length: 255 }),
  insurancePolicyNo: varchar("insurance_policy_no", { length: 100 }),
  insuranceCoverage: decimal("insurance_coverage", { precision: 14, scale: 2 }),
  address: text("address"),
  city: varchar("city", { length: 120 }),
  state: varchar("state", { length: 120 }),
  abhaId: varchar("abha_id", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// DOCTORS
// ─────────────────────────────────────────────

export const doctors = pgTable("doctors", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  registrationNo: varchar("registration_no", { length: 100 }).unique(),
  qualifications: text("qualifications"), // e.g. "MBBS, MD (Cardiology)"
  specialization: varchar("specialization", { length: 255 }).notNull(),
  departmentId: integer("department_id").references(() => departments.id),
  hospitalId: integer("hospital_id").references(() => hospitals.id),
  yearsOfExperience: integer("years_of_experience").default(0),
  consultationFee: decimal("consultation_fee", { precision: 10, scale: 2 }).default("0"),
  videoConsultFee: decimal("video_consult_fee", { precision: 10, scale: 2 }).default("0"),
  rating: doublePrecision("rating").default(0),
  ratingCount: integer("rating_count").default(0),
  bio: text("bio"),
  languages: text("languages"), // comma-separated
  availableToday: boolean("available_today").default(true),
  videoConsultAvailable: boolean("video_consult_available").default(true),
  homeVisitAvailable: boolean("home_visit_available").default(false),
  acceptsInsurance: boolean("accepts_insurance").default(true),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// APPOINTMENTS
// ─────────────────────────────────────────────

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  bookingId: varchar("booking_id", { length: 50 }).unique(), // e.g. "APPT-20240315-XXXX"
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  doctorId: integer("doctor_id").references(() => doctors.id).notNull(),
  hospitalId: integer("hospital_id").references(() => hospitals.id),
  appointmentDate: date("appointment_date").notNull(),
  timeSlot: varchar("time_slot", { length: 20 }).notNull(), // e.g. "10:30 AM"
  visitType: varchar("visit_type", { length: 30 }).default("in-person"), // in-person, video, home
  status: varchar("status", { length: 30 }).default("pending").notNull(), // pending, confirmed, completed, cancelled, rescheduled, no-show
  symptoms: text("symptoms"),
  notes: text("notes"),
  paymentMethod: varchar("payment_method", { length: 30 }), // online, hospital, insurance
  paymentStatus: varchar("payment_status", { length: 30 }).default("unpaid"),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  qrCode: varchar("qr_code", { length: 500 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

// ─────────────────────────────────────────────
// PRESCRIPTIONS
// ─────────────────────────────────────────────

export const prescriptions = pgTable("prescriptions", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  doctorId: integer("doctor_id").references(() => doctors.id).notNull(),
  appointmentId: integer("appointment_id").references(() => appointments.id),
  diagnosis: text("diagnosis"),
  notes: text("notes"),
  issuedAt: timestamp("issued_at").defaultNow().notNull(),
});

export const prescriptionItems = pgTable("prescription_items", {
  id: serial("id").primaryKey(),
  prescriptionId: integer("prescription_id").references(() => prescriptions.id).notNull(),
  medicineName: varchar("medicine_name", { length: 255 }).notNull(),
  dosage: varchar("dosage", { length: 100 }).notNull(), // e.g. "1-0-1"
  frequency: varchar("frequency", { length: 100 }), // e.g. "After meals"
  duration: varchar("duration", { length: 100 }), // e.g. "7 days"
  instructions: text("instructions"),
  quantity: integer("quantity").default(1),
  isGeneric: boolean("is_generic").default(false),
});

// ─────────────────────────────────────────────
// MEDICINES / PHARMACY
// ─────────────────────────────────────────────

export const medicines = pgTable("medicines", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  brand: varchar("brand", { length: 255 }),
  genericName: varchar("generic_name", { length: 255 }),
  manufacturer: varchar("manufacturer", { length: 255 }),
  category: varchar("category", { length: 100 }), // antibiotic, painkiller, etc.
  price: decimal("price", { precision: 10, scale: 2 }).default("0"),
  requiresPrescription: boolean("requires_prescription").default(false),
  stockQuantity: integer("stock_quantity").default(0),
  description: text("description"),
  sideEffects: text("side_effects"),
  isActive: boolean("is_active").default(true),
});

// ─────────────────────────────────────────────
// LAB TESTS
// ─────────────────────────────────────────────

export const labTests = pgTable("lab_tests", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  code: varchar("code", { length: 50 }),
  category: varchar("category", { length: 100 }), // blood, urine, thyroid, etc.
  price: decimal("price", { precision: 10, scale: 2 }).default("0"),
  homeCollection: boolean("home_collection").default(true),
  preparationInstructions: text("preparation_instructions"),
  normalRange: varchar("normal_range", { length: 255 }),
  turnaroundTime: varchar("turnaround_time", { length: 100 }), // e.g. "24 hours"
  isActive: boolean("is_active").default(true),
});

export const labOrders = pgTable("lab_orders", {
  id: serial("id").primaryKey(),
  orderId: varchar("order_id", { length: 50 }).unique(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  doctorId: integer("doctor_id").references(() => doctors.id),
  collectionMethod: varchar("collection_method", { length: 30 }).default("home"), // home, lab
  collectionDate: timestamp("collection_date"),
  status: varchar("status", { length: 30 }).default("booked"), // booked, collected, processing, completed, reported
  reportUrl: varchar("report_url", { length: 500 }),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }),
  paymentStatus: varchar("payment_status", { length: 30 }).default("unpaid"),
  bookedAt: timestamp("booked_at").defaultNow().notNull(),
});

export const labOrderItems = pgTable("lab_order_items", {
  id: serial("id").primaryKey(),
  labOrderId: integer("lab_order_id").references(() => labOrders.id).notNull(),
  labTestId: integer("lab_test_id").references(() => labTests.id).notNull(),
  result: text("result"),
  resultValue: varchar("result_value", { length: 255 }),
  unit: varchar("unit", { length: 50 }),
  isAbnormal: boolean("is_abnormal").default(false),
});

// ─────────────────────────────────────────────
// BILLING
// ─────────────────────────────────────────────

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  invoiceNo: varchar("invoice_no", { length: 50 }).unique(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  appointmentId: integer("appointment_id").references(() => appointments.id),
  type: varchar("type", { length: 30 }).default("consultation"), // consultation, pharmacy, lab, surgery, ipd
  description: text("description"),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  tax: decimal("tax", { precision: 12, scale: 2 }).default("0"),
  discount: decimal("discount", { precision: 12, scale: 2 }).default("0"),
  totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).notNull(),
  status: varchar("status", { length: 30 }).default("unpaid"), // unpaid, paid, partially-paid, refunded
  paymentMethod: varchar("payment_method", { length: 30 }),
  paymentDate: timestamp("payment_date"),
  insuranceClaimed: boolean("insurance_claimed").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// VITALS TRACKING
// ─────────────────────────────────────────────

export const vitalsReadings = pgTable("vitals_readings", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  bpSystolic: integer("bp_systolic"),
  bpDiastolic: integer("bp_diastolic"),
  heartRate: integer("heart_rate"),
  spo2: integer("spo2"),
  temperature: doublePrecision("temperature"),
  weightKg: doublePrecision("weight_kg"),
  bloodSugar: doublePrecision("blood_sugar"),
  bmi: doublePrecision("bmi"),
  recordedBy: varchar("recorded_by", { length: 100 }).default("patient"),
  recordedAt: timestamp("recorded_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// NOTIFICATIONS
// ─────────────────────────────────────────────

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  type: varchar("type", { length: 50 }), // appointment, medicine, report, billing, general
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  link: varchar("link", { length: 500 }),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// FEEDBACK & REVIEWS
// ─────────────────────────────────────────────

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  doctorId: integer("doctor_id").references(() => doctors.id),
  appointmentId: integer("appointment_id").references(() => appointments.id),
  rating: integer("rating").notNull(),
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────
// HEALTH PACKAGES & ARTICLES
// ─────────────────────────────────────────────

export const healthPackages = pgTable("health_packages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  features: jsonb("features"),
  ageGroup: varchar("age_group", { length: 100 }),
  category: varchar("category", { length: 100 }),
  popular: boolean("popular").default(false),
  isActive: boolean("is_active").default(true),
});

export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).unique(),
  excerpt: text("excerpt"),
  content: text("content"),
  category: varchar("category", { length: 100 }),
  authorName: varchar("author_name", { length: 255 }),
  imageUrl: varchar("image_url", { length: 500 }),
  publishedAt: timestamp("published_at").defaultNow().notNull(),
  isPublished: boolean("is_published").default(true),
});
