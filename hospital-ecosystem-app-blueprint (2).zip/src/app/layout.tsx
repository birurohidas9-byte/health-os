import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "MedVerse | Apollo-Grade Hospital Ecosystem",
  description:
    "A complete hospital ecosystem - patient portal, doctor dashboard, pharmacy, lab diagnostics, emergency care and hospital administration all in one place.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
