"use client";

import { useState } from "react";
import Navbar from "@/components/Navbar";
import { IconAmbulance, IconPhone, IconMapPin, IconClock, IconUsers } from "@/components/icons";

export default function EmergencyPage() {
  const [activated, setActivated] = useState(false);
  const [ambulanceBooked, setAmbulanceBooked] = useState(false);

  return (
    <div className="min-h-screen">
      <Navbar />
      <section className="bg-gradient-to-br from-red-600 via-red-700 to-rose-800 py-16">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-white sm:text-5xl">Emergency & SOS</h1>
          <p className="mx-auto mt-3 max-w-xl text-lg text-red-100">One tap connects you to the nearest ambulance, brings your medical info to the hospital, and alerts your family.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <span className="rounded-full bg-white/15 px-4 py-1.5 text-sm text-white">24×7 Helpline: <b>1800 200 1100</b></span>
            <span className="rounded-full bg-white/15 px-4 py-1.5 text-sm text-white">Ambulance National: <b>108</b></span>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          {/* SOS Card */}
          <div className="flex flex-col items-center justify-center rounded-3xl border-2 border-red-100 bg-white p-10 text-center shadow-sm">
            {activated ? (
              <>
                <div className="mb-4 h-20 w-20 animate-pulse rounded-full bg-red-500" style={{ boxShadow: "0 0 0 12px rgba(239,68,68,0.2)" }} />
                <h2 className="text-2xl font-bold text-red-600">SOS Activated!</h2>
                <p className="mt-2 text-slate-600">Nearest ambulance has been alerted. Your live location is being shared with dispatch and your emergency contact.</p>
                <div className="mt-6 w-full space-y-3 rounded-2xl bg-slate-50 p-5 text-left">
                  <div className="flex items-center gap-2 text-sm"><IconMapPin className="h-4 w-4 text-red-500" /> Location shared: MG Road, Bengaluru</div>
                  <div className="flex items-center gap-2 text-sm"><IconAmbulance className="h-4 w-4 text-red-500" /> Ambulance en route: BLS-2045</div>
                  <div className="flex items-center gap-2 text-sm"><IconClock className="h-4 w-4 text-red-500" /> Estimated arrival: 8 minutes</div>
                </div>
                <button onClick={() => setActivated(false)} className="mt-6 rounded-lg border border-slate-200 px-6 py-2 text-sm font-medium text-slate-600">
                  Cancel SOS
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => { setActivated(true); setAmbulanceBooked(true); }}
                  className="group flex h-40 w-40 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-rose-600 text-white shadow-xl shadow-red-200 transition-transform hover:scale-105"
                >
                  <span className="text-xl font-bold">SOS</span>
                </button>
                <h2 className="mt-6 text-xl font-bold text-slate-900">Tap to Trigger Emergency Alert</h2>
                <p className="mt-2 max-w-sm text-sm text-slate-500">
                  One tap immediately shares your GPS location with dispatch, books the nearest ambulance, and notifies your emergency contacts via SMS.
                </p>
              </>
            )}
          </div>

          {/* Ambulance booking */}
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">Ambulance Booking</h2>
              <span className="rounded-full bg-red-50 px-3 py-1 text-xs font-semibold text-red-600">Live</span>
            </div>

            {ambulanceBooked ? (
              <div className="mt-6 rounded-2xl bg-emerald-50 p-6">
                <p className="flex items-center gap-2 font-semibold text-emerald-700"><IconAmbulance className="h-5 w-5" /> Ambulance BLS-2045 assigned</p>
                <ol className="mt-4 space-y-3">
                  {[
                    { status: "Done", label: "Request received", time: "Now" },
                    { status: "Done", label: "Ambulance dispatched", time: "1 min" },
                    { status: "Active", label: "En route to you", time: "ETA 8 min" },
                    { status: "Pending", label: "Hospital handover", time: "—" },
                  ].map((s, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <span className={`h-3 w-3 rounded-full ${s.status === "Done" ? "bg-emerald-500" : s.status === "Active" ? "animate-pulse bg-red-500" : "bg-slate-300"}`} />
                      <div className="flex flex-1 justify-between text-sm">
                        <span className="font-medium text-slate-700">{s.label}</span>
                        <span className="text-slate-400">{s.time}</span>
                      </div>
                    </li>
                  ))}
                </ol>
              </div>
            ) : (
              <div className="mt-6 space-y-3">
                {[
                  { name: "Basic Life Support (BLS)", type: "For non-critical transport", time: "10-15 min" },
                  { name: "Advanced Life Support (ALS)", type: "ICU-equipped with paramedic", time: "10-20 min" },
                  { name: "Neonatal Ambulance", type: "For newborns & infants", time: "20-30 min" },
                  { name: "Air Ambulance", type: "Inter-city / inter-country transfer", time: "By arrangement" },
                ].map((a, i) => (
                  <button key={a.name} onClick={() => setAmbulanceBooked(true)} className="flex w-full items-center justify-between rounded-xl border border-slate-200 p-4 text-left transition-colors hover:border-red-200 hover:bg-red-50">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-50 text-red-500"><IconAmbulance className="h-5 w-5" /></div>
                      <div>
                        <p className="font-semibold text-slate-900">{a.name}</p>
                        <p className="text-xs text-slate-500">{a.type}</p>
                      </div>
                    </div>
                    <span className="text-xs text-slate-400">{a.time}</span>
                  </button>
                ))}
              </div>
            )}

            <div className="mt-6 rounded-2xl bg-slate-50 p-5">
              <p className="flex items-center gap-2 text-sm font-semibold text-slate-700"><IconUsers className="h-4 w-4" /> Your Emergency Card</p>
              <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
                <div><p className="text-xs text-slate-400">Blood Group</p><p className="font-semibold text-slate-900">O+</p></div>
                <div><p className="text-xs text-slate-400">Allergies</p><p className="font-semibold text-slate-900">Penicillin</p></div>
                <div><p className="text-xs text-slate-400">Chronic Conditions</p><p className="font-semibold text-slate-900">Hypertension</p></div>
                <div><p className="text-xs text-slate-400">Emergency Contact</p><p className="font-semibold text-slate-900">Sunita +91 91234</p></div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact numbers */}
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { name: "MedVerse ER", num: "1800 200 1100", color: "border-red-200" },
            { name: "National Ambulance", num: "108", color: "border-emerald-200" },
            { name: "Blood Bank HelpDesk", num: "102 + 9", color: "border-blue-200" },
            { name: "Poison Control", num: "22 2284 3331", color: "border-amber-200" },
          ].map((c) => (
            <div key={c.name} className={`flex items-center justify-between rounded-2xl border ${c.color} bg-white p-5 shadow-sm`}>
              <div className="flex items-center gap-3">
                <IconPhone className="h-5 w-5 text-slate-600" />
                <div>
                  <p className="text-sm font-semibold text-slate-900">{c.name}</p>
                  <p className="text-xs text-slate-500">{c.num}</p>
                </div>
              </div>
              <button className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-medium text-slate-700">Call</button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
