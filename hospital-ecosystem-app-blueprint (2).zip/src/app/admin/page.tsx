"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import {
  IconChart, IconUser, IconUsers, IconStethoscope, IconCalendar,
  IconBed, IconPill, IconTestTube, IconWallet, IconBell, IconSearch,
  IconActivity, IconHeartPulse, IconMapPin, IconArrowRight, IconShield,
} from "@/components/icons";

interface Stats {
  patients: number;
  doctors: number;
  appointments: number;
  hospitals: number;
  departments: number;
  totalRevenue: number;
  completedAppointments: number;
  pendingAppointments: number;
  medicines: number;
  labTests: number;
  prescriptions: number;
  newPatientsToday: number;
}

export default function AdminPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState("dashboard");

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/stats");
        setStats(await res.json());
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const sidebarSections = [
    { key: "dashboard", label: "Analytics Dashboard", icon: IconChart },
    { key: "patients", label: "Patient Management", icon: IconUser },
    { key: "doctors", label: "Doctor Management", icon: IconStethoscope },
    { key: "appointments", label: "Appointments", icon: IconCalendar },
    { key: "hospital", label: "Hospital / Beds", icon: IconBed },
    { key: "pharmacy", label: "Pharmacy Stock", icon: IconPill },
    { key: "lab", label: "Lab & Diagnostics", icon: IconTestTube },
    { key: "finance", label: "Finance", icon: IconWallet },
    { key: "crm", label: "Marketing & CRM", icon: IconHeartPulse },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="mx-auto flex max-w-7xl gap-6 px-4 py-8 sm:px-6 lg:px-8">
        {/* Sidebar */}
        <aside className="hidden w-60 shrink-0 lg:block">
          <div className="sticky top-20 space-y-1">
            {sidebarSections.map((section) => (
              <button
                key={section.key}
                onClick={() => setActiveSection(section.key)}
                className={`flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-left text-sm font-medium transition-colors ${
                  activeSection === section.key ? "bg-teal-600 text-white shadow-sm" : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <section.icon className="h-4 w-4" /> {section.label}
              </button>
            ))}
            <div className="mt-6 rounded-xl bg-slate-100 p-4">
              <p className="flex items-center gap-2 text-xs font-semibold text-slate-700"><IconShield className="h-4 w-4" /> Super Admin</p>
              <p className="mt-1 text-xs text-slate-500">Dr. Vishal Sharma<br />admin@medverse.com</p>
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main className="min-w-0 flex-1 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">Hospital Command Center</h1>
              <p className="text-sm text-slate-500">Real-time overview across all {stats?.hospitals ?? 0} branches</p>
            </div>
            <div className="flex gap-2">
              <button className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 shadow-sm">Export</button>
              <button className="rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white shadow-sm">+ New Entry</button>
            </div>
          </div>

          {activeSection === "dashboard" && (
            <>
              {/* KPI cards */}
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {[
                  { label: "Total Patients", value: loading ? "…" : String(stats?.patients ?? 0), icon: IconUser, delta: "+8 this week", color: "from-teal-500 to-emerald-600" },
                  { label: "Revenue (Paid)", value: loading ? "…" : `₹${((stats?.totalRevenue ?? 0) / 1000).toFixed(0)}K`, icon: IconWallet, delta: "+12% vs last month", color: "from-blue-500 to-indigo-600" },
                  { label: "Appointments", value: loading ? "…" : String(stats?.appointments ?? 0), icon: IconCalendar, delta: `${stats?.pendingAppointments ?? 0} pending`, color: "from-amber-500 to-orange-600" },
                  { label: "Active Doctors", value: loading ? "…" : String(stats?.doctors ?? 0), icon: IconStethoscope, delta: "+2 onboarding", color: "from-purple-500 to-fuchsia-600" },
                ].map((kpi) => (
                  <div key={kpi.label} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div className="flex items-center justify-between">
                      <div className={`flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${kpi.color} text-white`}>
                        <kpi.icon className="h-5 w-5" />
                      </div>
                      <span className="text-xs font-medium text-emerald-600">{kpi.delta}</span>
                    </div>
                    <p className="mt-4 text-3xl font-bold text-slate-900">{kpi.value}</p>
                    <p className="text-sm text-slate-500">{kpi.label}</p>
                  </div>
                ))}
              </div>

              {/* Analytics chart block */}
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-slate-900">Revenue & Appointments Trend</h2>
                  <div className="flex gap-2">
                    {["7D", "30D", "90D"].map((p) => (
                      <button key={p} className={`rounded-lg px-3 py-1 text-xs font-medium ${p === "30D" ? "bg-teal-600 text-white" : "bg-slate-100 text-slate-600"}`}>{p}</button>
                    ))}
                  </div>
                </div>
                <div className="mt-6 flex h-56 items-end gap-3">
                  {[42, 55, 40, 62, 70, 58, 80, 66, 75, 88, 72, 95].map((v, i) => {
                    const isUp = i >= 7;
                    return (
                      <div key={i} className="flex h-full flex-1 flex-col items-center justify-end gap-2">
                        {i === 11 && <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[9px] font-bold text-emerald-700">+24%</span>}
                        <div
                          className={`w-full rounded-t-lg ${isUp ? "bg-gradient-to-t from-teal-600 to-emerald-400" : "bg-slate-200"}`}
                          style={{ height: `${v}%` }}
                        />
                        <span className="text-[10px] text-slate-400">{["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"][i]}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Two column bottom */}
              <div className="grid gap-6 lg:grid-cols-2">
                {/* Department performance */}
                <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                  <h2 className="text-lg font-semibold text-slate-900">Top Departments</h2>
                  <div className="mt-4 space-y-4">
                    {[
                      { name: "Cardiology", pct: 78, appts: 1240, rev: "₹4.2L" },
                      { name: "Orthopedics", pct: 65, appts: 980, rev: "₹3.6L" },
                      { name: "Gynecology", pct: 58, appts: 870, rev: "₹2.9L" },
                      { name: "Dermatology", pct: 48, appts: 720, rev: "₹2.1L" },
                      { name: "Neurology", pct: 42, appts: 640, rev: "₹1.9L" },
                    ].map((d) => (
                      <div key={d.name}>
                        <div className="mb-1 flex justify-between text-sm">
                          <span className="font-medium text-slate-700">{d.name}</span>
                          <span className="text-slate-400">{d.rev}</span>
                        </div>
                        <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                          <div className="h-full rounded-full bg-gradient-to-r from-teal-500 to-emerald-400" style={{ width: `${d.pct}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bed occupancy */}
                <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                  <h2 className="text-lg font-semibold text-slate-900">Bed Occupancy</h2>
                  <div className="mt-6 flex items-center gap-8">
                    <div className="relative flex h-36 w-36 items-center justify-center">
                      <svg viewBox="0 0 36 36" className="h-full w-full -rotate-90">
                        <circle cx="18" cy="18" r="15.9" fill="none" stroke="#e2e8f0" strokeWidth="3.4" />
                        <circle cx="18" cy="18" r="15.9" fill="none" stroke="#0d9488" strokeWidth="3.4" strokeLinecap="round" strokeDasharray="100" strokeDashoffset="32" />
                      </svg>
                      <div className="absolute text-center">
                        <p className="text-3xl font-bold text-slate-900">68%</p>
                        <p className="text-xs text-slate-400">occupied</p>
                      </div>
                    </div>
                    <div className="space-y-3 text-sm">
                      <div className="flex items-center justify-between gap-10"><span className="text-slate-500">Total beds</span><b className="text-slate-900">1050</b></div>
                      <div className="flex items-center justify-between gap-10"><span className="text-slate-500">Occupied</span><b className="text-slate-900">714</b></div>
                      <div className="flex items-center justify-between gap-10"><span className="text-slate-500">ICU beds</span><b className="text-slate-900">153</b></div>
                      <div className="flex items-center justify-between gap-10"><span className="text-red-500">ICU occupied</span><b className="text-red-500">124</b></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent activity */}
              <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div className="flex items-center justify-between border-b border-slate-100 p-5">
                  <h2 className="text-lg font-semibold text-slate-900">Recent Activity</h2>
                  <button className="relative rounded-lg border border-slate-200 p-2 text-slate-500"><IconBell className="h-4 w-4" /></button>
                </div>
                <div className="divide-y divide-slate-50">
                  {[
                    { text: "New appointment booked — Dr. Mehta + Priya D.", time: "2 min ago", icon: IconCalendar },
                    { text: "Pharmacy order #8851 fulfilled", time: "15 min ago", icon: IconPill },
                    { text: "Lab report released — Lipid Profile #332", time: "28 min ago", icon: IconTestTube },
                    { text: "Patient Rahul K. checked-in (Cardiology OPD)", time: "45 min ago", icon: IconUser },
                    { text: "Invoice INV-1003 marked unpaid — follow up", time: "1 hr ago", icon: IconWallet },
                  ].map((a, i) => (
                    <div key={i} className="flex items-center gap-4 p-4">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-teal-50 text-teal-600"><a.icon className="h-4 w-4" /></div>
                      <p className="flex-1 text-sm text-slate-700">{a.text}</p>
                      <span className="text-xs text-slate-400">{a.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeSection === "patients" && (
            <PatientsPanel />
          )}
          {activeSection === "doctors" && (
            <DoctorsPanel />
          )}
          {activeSection === "pharmacy" && (
            <PharmacyPanel />
          )}
          {activeSection === "lab" && (
            <LabPanel />
          )}
          {activeSection === "finance" && (
            <FinancePanel />
          )}
        </main>
      </div>
    </div>
  );
}

/* ── Panel components ───────────────────────── */

interface Patient {
  id: number;
  name: string;
  medicalId: string;
  bloodGroup: string;
  gender: string;
  phone: string;
  city: string;
  insuranceProvider: string;
}

function PatientsPanel() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/patients").then((r) => r.json()).then(setPatients).finally(() => setLoading(false));
  }, []);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 p-5">
        <h2 className="text-lg font-semibold text-slate-900">Patient Database</h2>
        <div className="flex max-w-sm flex-1 items-center gap-2 rounded-lg border border-slate-200 px-3 py-2">
          <IconSearch className="h-4 w-4 text-slate-400" />
          <input placeholder="Search patients..." className="w-full text-sm outline-none" />
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-5 py-3 font-medium">Patient</th>
              <th className="px-5 py-3 font-medium">Medical ID</th>
              <th className="px-5 py-3 font-medium">Blood</th>
              <th className="px-5 py-3 font-medium">Location</th>
              <th className="px-5 py-3 font-medium">Insurance</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {loading ? (
              <tr><td colSpan={5} className="px-5 py-6 text-center text-slate-400">Loading...</td></tr>
            ) : patients.length === 0 ? (
              <tr><td colSpan={5} className="px-5 py-6 text-center text-slate-400">No patients found. Run seed.</td></tr>
            ) : (
              patients.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-teal-100 text-xs font-bold text-teal-700">
                        {p.name?.split(" ").map((w) => w[0]).slice(0, 2).join("")}
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">{p.name}</p>
                        <p className="text-xs text-slate-400">{p.gender} · {p.phone}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-slate-600">{p.medicalId}</td>
                  <td className="px-5 py-3"><span className="rounded bg-red-50 px-2 py-1 text-xs font-semibold text-red-600">{p.bloodGroup}</span></td>
                  <td className="px-5 py-3 text-slate-600">{p.city}</td>
                  <td className="px-5 py-3 text-slate-600">{p.insuranceProvider || "—"}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface Doctor {
  id: number;
  specialization: string;
  consultationFee: string;
  rating: number;
  hospitalName: string;
  name: string;
}

function DoctorsPanel() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  useEffect(() => {
    fetch("/api/doctors").then((r) => r.json()).then(setDoctors).catch(() => {});
  }, []);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 p-5"><h2 className="text-lg font-semibold text-slate-900">Doctor Management</h2></div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr><th className="px-5 py-3">Doctor</th><th className="px-5 py-3">Specialization</th><th className="px-5 py-3">Fee</th><th className="px-5 py-3">Rating</th><th className="px-5 py-3">Hospital</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {doctors.map((d) => (
              <tr key={d.id} className="hover:bg-slate-50">
                <td className="px-5 py-3 font-medium text-slate-900">{d.name}</td>
                <td className="px-5 py-3 text-slate-600">{d.specialization}</td>
                <td className="px-5 py-3 text-slate-600">₹{d.consultationFee}</td>
                <td className="px-5 py-3"><span className="flex w-fit items-center gap-1 rounded bg-emerald-50 px-2 py-1 text-xs font-semibold text-emerald-600">★ {d.rating}</span></td>
                <td className="px-5 py-3 text-slate-600">{d.hospitalName}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface Medicine {
  id: number; name: string; brand: string; category: string; price: string; stockQuantity: number;
}

function PharmacyPanel() {
  const [meds, setMeds] = useState<Medicine[]>([]);
  useEffect(() => {
    fetch("/api/medicines").then((r) => r.json()).then(setMeds).catch(() => {});
  }, []);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 p-5"><h2 className="text-lg font-semibold text-slate-900">Pharmacy Inventory</h2></div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr><th className="px-5 py-3">Medicine</th><th className="px-5 py-3">Brand</th><th className="px-5 py-3">Category</th><th className="px-5 py-3">Price</th><th className="px-5 py-3">Stock</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {meds.map((m) => (
              <tr key={m.id} className="hover:bg-slate-50">
                <td className="px-5 py-3 font-medium text-slate-900">{m.name}</td>
                <td className="px-5 py-3 text-slate-600">{m.brand}</td>
                <td className="px-5 py-3 text-slate-600">{m.category}</td>
                <td className="px-5 py-3 text-slate-600">₹{m.price}</td>
                <td className="px-5 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${m.stockQuantity > 200 ? "bg-emerald-50 text-emerald-600" : m.stockQuantity > 100 ? "bg-amber-50 text-amber-600" : "bg-red-50 text-red-600"}`}>
                    {m.stockQuantity} units
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface LabTest {
  id: number; name: string; category: string; price: string; turnaroundTime: string; homeCollection: boolean;
}

function LabPanel() {
  const [tests, setTests] = useState<LabTest[]>([]);
  useEffect(() => {
    fetch("/api/lab-tests").then((r) => r.json()).then(setTests).catch(() => {});
  }, []);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 p-5"><h2 className="text-lg font-semibold text-slate-900">Lab Test Catalog</h2></div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr><th className="px-5 py-3">Test</th><th className="px-5 py-3">Category</th><th className="px-5 py-3">TAT</th><th className="px-5 py-3">Home</th><th className="px-5 py-3">Price</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {tests.map((t) => (
              <tr key={t.id} className="hover:bg-slate-50">
                <td className="px-5 py-3 font-medium text-slate-900">{t.name}</td>
                <td className="px-5 py-3 text-slate-600">{t.category}</td>
                <td className="px-5 py-3 text-slate-600">{t.turnaroundTime}</td>
                <td className="px-5 py-3">{t.homeCollection ? "✓" : "—"}</td>
                <td className="px-5 py-3 text-slate-600">₹{t.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function FinancePanel() {
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">Revenue Breakdown</h2>
        <div className="mt-6 space-y-4">
          {[
            { name: "Consultations", amt: "₹2.4L", pct: 38 },
            { name: "Pharmacy Sales", amt: "₹1.8L", pct: 29 },
            { name: "Lab Diagnostics", amt: "₹1.1L", pct: 18 },
            { name: "IPD / Surgeries", amt: "₹0.9L", pct: 15 },
          ].map((r) => (
            <div key={r.name}>
              <div className="mb-1 flex justify-between text-sm"><span className="font-medium text-slate-700">{r.name}</span><span className="text-slate-900 font-semibold">{r.amt}</span></div>
              <div className="h-2 rounded-full bg-slate-100"><div className="h-full rounded-full bg-gradient-to-r from-teal-500 to-emerald-400" style={{ width: `${r.pct}%` }} /></div>
            </div>
          ))}
        </div>
      </div>
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">Payment Status</h2>
        <div className="mt-6 space-y-3 text-sm">
          {[
            { label: "Collected this month", amt: "₹6.2L", color: "text-emerald-600" },
            { label: "Pending payments", amt: "₹1.4L", color: "text-amber-600" },
            { label: "Insurance claims pending", amt: "₹2.9L", color: "text-purple-600" },
            { label: "Refunds processed", amt: "₹0.2L", color: "text-slate-600" },
          ].map((row) => (
            <div key={row.label} className="flex items-center justify-between rounded-xl bg-slate-50 p-4">
              <span className="text-slate-600">{row.label}</span>
              <b className={row.color}>{row.amt}</b>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
