"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import {
  IconCalendar, IconFile, IconHeartPulse, IconPill, IconUser,
  IconTestTube, IconArrowRight, IconActivity, IconWallet, IconShield,
} from "@/components/icons";
import Link from "next/link";

interface Appointment {
  id: number;
  bookingId: string;
  appointmentDate: string;
  timeSlot: string;
  visitType: string;
  status: string;
  symptoms: string;
  paymentStatus: string;
  amount: string;
  doctorName: string;
  doctorSpecialization: string;
  hospitalName: string;
}

interface DashboardData {
  patients: number;
  doctors: number;
  appointments: number;
  hospitals: number;
  totalRevenue: number;
}

export default function PatientPortalPage() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/appointments?patientId=1");
        setAppointments(await res.json());
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Patient header */}
      <section className="border-b border-slate-200 bg-gradient-to-br from-teal-700 via-teal-800 to-emerald-900 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-white text-2xl font-bold text-teal-700 shadow-lg">RK</div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-white">Rahul Khanna</h1>
              <p className="text-teal-200">Medical ID: MV-PAT-10001 · O+ · 33 yrs, Male</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <span className="rounded-full bg-white/15 px-3 py-1 text-xs text-teal-50">🔴 Allergy: Penicillin</span>
                <span className="rounded-full bg-white/15 px-3 py-1 text-xs text-teal-50">Condition: Hypertension</span>
                <span className="rounded-full bg-white/15 px-3 py-1 text-xs text-teal-50">Insurance: Star Health ₹5L</span>
              </div>
            </div>
            <Link href="/appointment/new" className="rounded-xl bg-white px-6 py-3 text-sm font-semibold text-teal-800 shadow-lg transition-transform hover:scale-[1.02]">
              + Book Appointment
            </Link>
          </div>
        </div>
      </section>

      {/* Tabs */}
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl gap-6 overflow-x-auto px-4 py-3 sm:px-6 lg:px-8">
          {[
            { key: "overview", label: "Overview", icon: IconUser },
            { key: "appointments", label: "Appointments", icon: IconCalendar },
            { key: "records", label: "Health Records", icon: IconFile },
            { key: "vitals", label: "Vitals", icon: IconHeartPulse },
            { key: "prescriptions", label: "Prescriptions", icon: IconPill },
            { key: "bills", label: "Billing", icon: IconWallet },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex shrink-0 items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                activeTab === tab.key ? "bg-teal-50 text-teal-700" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              <tab.icon className="h-4 w-4" /> {tab.label}
            </button>
          ))}
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {activeTab === "overview" && (
          <div className="space-y-8">
            {/* Quick stats */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { label: "Upcoming Appointments", value: appointments.length || "—", icon: IconCalendar, color: "bg-teal-50 text-teal-600" },
                { label: "Prescriptions Active", value: "2", icon: IconPill, color: "bg-amber-50 text-amber-600" },
                { label: "Lab Reports", value: "5", icon: IconTestTube, color: "bg-purple-50 text-purple-600" },
                { label: "Pending Bills", value: "₹1,203", icon: IconWallet, color: "bg-red-50 text-red-600" },
              ].map((stat) => (
                <div key={stat.label} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className={`mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl ${stat.color}`}>
                    <stat.icon className="h-5 w-5" />
                  </div>
                  <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                  <p className="text-sm text-slate-500">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Upcoming appointments */}
            <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-100 p-5">
                <h2 className="text-lg font-semibold text-slate-900">Upcoming Appointments</h2>
                <button onClick={() => setActiveTab("appointments")} className="text-sm font-medium text-teal-600 hover:text-teal-700">View all →</button>
              </div>
              <div className="divide-y divide-slate-100">
                {loading ? (
                  <div className="p-5 text-sm text-slate-400">Loading appointments...</div>
                ) : appointments.length === 0 ? (
                  <div className="p-5 text-sm text-slate-400">No upcoming appointments.</div>
                ) : (
                  appointments.map((a) => (
                    <div key={a.id} className="flex flex-wrap items-center justify-between gap-4 p-5">
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 flex-col items-center justify-center rounded-xl bg-teal-50 text-teal-700">
                          <span className="text-sm font-bold">{new Date(a.appointmentDate).getDate()}</span>
                          <span className="text-[10px] uppercase">{new Date(a.appointmentDate).toLocaleDateString("en-IN", { month: "short" })}</span>
                        </div>
                        <div>
                          <p className="font-semibold text-slate-900">{a.doctorName}</p>
                          <p className="text-sm text-slate-500">{a.doctorSpecialization}</p>
                          <p className="text-xs text-slate-400">{a.hospitalName} · {a.timeSlot}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`rounded-full px-3 py-1 text-xs font-semibold ${
                          a.status === "confirmed" ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"
                        }`}>{a.status}</span>
                        <Link href={`/doctors/${a.id}`} className="rounded-lg bg-teal-600 px-3 py-1.5 text-xs font-semibold text-white">Details</Link>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Vitals & reminders */}
            <div className="grid gap-6 lg:grid-cols-3">
              <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-slate-900">Recent Vitals</h2>
                  <button onClick={() => setActiveTab("vitals")} className="text-sm text-teal-600">View all →</button>
                </div>
                <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3">
                  {[
                    { label: "Blood Pressure", value: "125/82", unit: "mmHg", normal: true },
                    { label: "Heart Rate", value: "72", unit: "bpm", normal: true },
                    { label: "Blood Sugar (F)", value: "112", unit: "mg/dL", normal: false },
                    { label: "SpO2", value: "98", unit: "%", normal: true },
                    { label: "Temperature", value: "36.8", unit: "°C", normal: true },
                    { label: "BMI", value: "25.5", unit: "", normal: false },
                  ].map((v) => (
                    <div key={v.label} className="rounded-xl bg-slate-50 p-4 text-center">
                      <p className="text-xs text-slate-500">{v.label}</p>
                      <p className="mt-1 text-2xl font-bold text-slate-900">{v.value}<span className="text-sm font-normal text-slate-400"> {v.unit}</span></p>
                      <span className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold ${v.normal ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}>{v.normal ? "Normal" : "Review"}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="text-lg font-semibold text-slate-900">Medicine Reminders</h2>
                <div className="mt-4 space-y-3">
                  {[
                    { med: "Amlodipine 5mg", time: "08:00 AM", taken: true },
                    { med: "Metformin 500mg", time: "08:00 AM", taken: true },
                    { med: "Amlodipine 5mg", time: "08:00 PM", taken: false },
                    { med: "Vitamin D3", time: "01:00 PM", taken: true },
                  ].map((r, i) => (
                    <div key={i} className="flex items-center justify-between rounded-xl border border-slate-100 p-3">
                      <div>
                        <p className="text-sm font-medium text-slate-900">{r.med}</p>
                        <p className="text-xs text-slate-400">{r.time}</p>
                      </div>
                      <span className={`h-4 w-4 rounded-full ${r.taken ? "bg-emerald-500" : "bg-slate-200"}`} />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Insurance card */}
            <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-700 p-6 text-white shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <IconShield className="h-10 w-10" />
                  <div>
                    <h3 className="text-lg font-bold">Star Health Insurance</h3>
                    <p className="text-sm text-purple-100">Policy: SH-8845-2019 · Sum insured ₹5,00,000</p>
                  </div>
                </div>
                <div className="rounded-xl bg-white/10 px-5 py-3 text-center backdrop-blur-sm">
                  <p className="text-xs text-purple-100">Insured members</p>
                  <p className="text-lg font-bold">4</p>
                </div>
                <button className="rounded-lg bg-white px-5 py-2.5 text-sm font-semibold text-purple-700">View Cover →</button>
              </div>
            </div>
          </div>
        )}

        {activeTab === "appointments" && (
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 p-5"><h2 className="text-lg font-semibold text-slate-900">All Appointments</h2></div>
            <div className="divide-y divide-slate-100">
              {appointments.length === 0 ? (
                <div className="p-10 text-center text-slate-400">No appointments yet.</div>
              ) : (
                appointments.map((a) => (
                  <div key={a.id} className="flex flex-wrap items-center justify-between gap-4 p-5">
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-50 text-teal-700"><IconCalendar className="h-5 w-5" /></div>
                      <div>
                        <p className="font-semibold text-slate-900">{a.doctorName} · {a.doctorSpecialization}</p>
                        <p className="text-sm text-slate-500">{a.appointmentDate} at {a.timeSlot} · {a.visitType}</p>
                        <p className="text-xs text-slate-400">Booking ID: {a.bookingId} · {a.hospitalName}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="rounded-full bg-teal-50 px-3 py-1 text-xs font-semibold text-teal-600">{a.status}</span>
                      <p className="mt-1 text-sm font-semibold text-slate-900">₹{a.amount}</p>
                      <p className="text-xs text-slate-400">{a.paymentStatus}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === "records" && (
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 p-5">
              <h2 className="text-lg font-semibold text-slate-900">Health Records</h2>
              <button className="rounded-lg border border-slate-200 px-4 py-1.5 text-sm font-medium text-slate-600">+ Upload Document</button>
            </div>
            <div className="divide-y divide-slate-100">
              {[
                { name: "Cardiology Report - Dr. Mehta", type: "Consultation Report", date: "12 Mar 2026", tag: "PDF" },
                { name: "Comprehensive Health Checkup", type: "Lab Report", date: "12 Mar 2026", tag: "PDF" },
                { name: "Lipid Profile Results", type: "Lab Report", date: "12 Mar 2026", tag: "PDF" },
                { name: "Discharge Summary - Ortho Surgery", type: "Discharge Summary", date: "18 Jan 2026", tag: "PDF" },
                { name: "Vaccination Record", type: "Vaccination", date: "05 Nov 2025", tag: "PDF" },
              ].map((doc) => (
                <div key={doc.name} className="flex flex-wrap items-center justify-between gap-4 p-5">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100 text-slate-500"><IconFile className="h-5 w-5" /></div>
                    <div>
                      <p className="font-medium text-slate-900">{doc.name}</p>
                      <p className="text-xs text-slate-400">{doc.type} · {doc.date}</p>
                    </div>
                  </div>
                  <span className="rounded bg-red-50 px-2 py-0.5 text-[10px] font-bold text-red-500">{doc.tag}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "vitals" && (
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">Vitals Tracking & Trends</h2>
            <p className="mb-6 mt-1 text-sm text-slate-500">Track your health metrics over time with smart visualizations.</p>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { label: "Blood Pressure", data: [132, 128, 126, 129, 125, 125], unit: "mmHg" },
                { label: "Heart Rate", data: [78, 75, 74, 73, 71, 72], unit: "bpm" },
                { label: "Blood Sugar (Fasting)", data: [128, 122, 118, 121, 115, 112], unit: "mg/dL" },
                { label: "Weight", data: [82, 81, 80.5, 80, 79, 78], unit: "kg" },
                { label: "SpO2", data: [97, 97, 98, 98, 98, 98], unit: "%" },
                { label: "Temperature", data: [36.7, 36.8, 36.6, 36.9, 36.8, 36.8], unit: "°C" },
              ].map((metric) => {
                const max = Math.max(...metric.data) * 1.15;
                const min = Math.min(...metric.data) * 0.85;
                return (
                  <div key={metric.label} className="rounded-xl border border-slate-100 p-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-slate-700">{metric.label}</p>
                      <span className="text-xs text-slate-400">{metric.unit}</span>
                    </div>
                    <div className="mt-3 flex h-20 items-end gap-1.5">
                      {metric.data.map((v, i) => (
                        <div key={i} className="flex flex-1 flex-col justify-end gap-1">
                          <div
                            className="w-full rounded-t bg-gradient-to-t from-teal-600 to-emerald-400"
                            style={{ height: `${((v - min) / (max - min)) * 72 + 8}px` }}
                          />
                        </div>
                      ))}
                    </div>
                    <p className="mt-2 text-right font-semibold text-teal-700">{metric.data[metric.data.length - 1]} <span className="text-xs font-normal text-slate-400">latest</span></p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === "prescriptions" && (
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 p-5"><h2 className="text-lg font-semibold text-slate-900">Prescriptions</h2></div>
            <div className="divide-y divide-slate-100">
              {[
                { doc: "Dr. Arjun Mehta", spec: "Cardiology", date: "12 Mar 2026", meds: ["Amlodipine 5mg · 1-0-1 · 30 days", "Metformin 500mg · 1-0-1 · 60 days", "Vitamin D3 · 1/week · 3 months"] },
                { doc: "Dr. Ravi Shankar", spec: "General Physician", date: "28 Jan 2026", meds: ["Paracetamol 500mg · 1-1-1 · 5 days", "Cetirizine 10mg · 0-0-1 · 7 days"] },
              ].map((p, i) => (
                <div key={i} className="p-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-slate-900">{p.doc}</p>
                      <p className="text-xs text-slate-400">{p.spec} · {p.date}</p>
                    </div>
                    <button className="rounded-lg bg-teal-600 px-4 py-1.5 text-xs font-semibold text-white">Order Medicines</button>
                  </div>
                  <ul className="mt-3 space-y-1 text-sm text-slate-600">
                    {p.meds.map((m) => <li key={m} className="flex items-center gap-2"><IconPill className="h-4 w-4 text-teal-500" />{m}</li>)}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "bills" && (
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 p-5"><h2 className="text-lg font-semibold text-slate-900">My Billing</h2></div>
            <div className="divide-y divide-slate-100">
              {[
                { inv: "INV-...-1001", desc: "Cardiology consultation", amt: "1,316", status: "Paid", method: "Insurance" },
                { inv: "INV-...-1003", desc: "Comprehensive Health Checkup", amt: "3,289", status: "Unpaid", method: "—" },
                { inv: "INV-...-9988", desc: "Medicine order", amt: "161", status: "Paid", method: "UPI" },
                { inv: "INV-...-9421", desc: "Lipid Profile", amt: "600", status: "Paid", method: "Card" },
              ].map((b) => (
                <div key={b.inv} className="flex flex-wrap items-center justify-between gap-4 p-5">
                  <div>
                    <p className="font-medium text-slate-900">{b.desc}</p>
                    <p className="text-xs text-slate-400">{b.inv}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-slate-900">₹{b.amt}</p>
                    <span className={`text-xs font-semibold ${b.status === "Paid" ? "text-emerald-600" : "text-red-500"}`}>{b.status} · {b.method}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
