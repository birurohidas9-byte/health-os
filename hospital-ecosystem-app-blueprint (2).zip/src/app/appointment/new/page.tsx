"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import { IconCalendar, IconStethoscope, IconVideo, IconMapPin, IconCheckCircle } from "@/components/icons";

interface Doctor {
  id: number;
  name: string;
  specialization: string;
  consultationFee: string;
  videoConsultFee: string;
  rating: number;
  hospitalName: string;
  hospitalCity: string;
}

export default function NewAppointmentPage() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctor, setSelectedDoctor] = useState<number | null>(null);
  const [visitType, setVisitType] = useState("in-person");
  const [symptoms, setSymptoms] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [dateIndex, setDateIndex] = useState(0);
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(true);

  const slots = ["09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"];

  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() + i * 86400000);
    return {
      label: i === 0 ? "Today" : d.toLocaleDateString("en-IN", { weekday: "short" }),
      date: d.toISOString().split("T")[0],
      day: d.getDate(),
    };
  });

  useEffect(() => {
    fetch("/api/doctors").then((r) => r.json()).then(setDoctors).finally(() => setLoading(false));
  }, []);

  const activeDoctor = doctors.find((d) => d.id === selectedDoctor);

  const handleSubmit = async () => {
    if (!selectedDoctor || !selectedSlot) return;
    const res = await fetch("/api/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        patientId: 1,
        doctorId: selectedDoctor,
        appointmentDate: dates[dateIndex].date,
        timeSlot: selectedSlot,
        visitType,
        symptoms,
        paymentMethod: "hospital",
        amount: activeDoctor ? activeDoctor.consultationFee : 0,
      }),
    });
    const data = await res.json();
    if (data.success) setSuccess(true);
  };

  if (success) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="mx-auto max-w-lg px-4 py-20 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500 text-white">
            <IconCheckCircle className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Appointment Confirmed!</h1>
          <p className="mt-2 text-slate-600">Your appointment with <b>{activeDoctor?.name}</b> on {dates[dateIndex].date} at {selectedSlot} is confirmed.</p>
          <p className="mt-1 text-sm text-slate-500">Booking ID: APPT-{Date.now().toString().slice(-6)}</p>
          <button onClick={() => setSuccess(false)} className="mt-6 rounded-lg bg-teal-600 px-6 py-2.5 text-sm font-semibold text-white">Book Another</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <section className="border-b border-slate-200 bg-gradient-to-br from-teal-700 to-emerald-800 py-10">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-white">Book an Appointment</h1>
          <p className="mt-2 text-teal-100">Choose a doctor, pick a convenient slot, and you're all set.</p>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
          {/* Step 1: doctor */}
          <div className="mb-8">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900"><span className="rounded-full bg-teal-600 px-2.5 py-0.5 text-xs font-bold text-white">1</span> Select Doctor</h2>
            <div className="mt-4 max-h-64 overflow-y-auto space-y-2 pr-1">
              {loading ? <p className="text-sm text-slate-400">Loading doctors...</p> : doctors.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setSelectedDoctor(d.id)}
                  className={`flex w-full items-center justify-between rounded-xl border p-4 transition-colors ${
                    selectedDoctor === d.id ? "border-teal-600 bg-teal-50" : "border-slate-200 hover:border-teal-200"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-100 text-sm font-bold text-teal-700">
                      {d.name.replace("Dr. ", "").split(" ").map((w) => w[0]).slice(0, 2).join("")}
                    </div>
                    <div className="text-left">
                      <p className="font-semibold text-slate-900">{d.name}</p>
                      <p className="text-sm text-teal-600">{d.specialization}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-900">₹{d.consultationFee}</p>
                    <p className="text-xs text-amber-500">★ {d.rating}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: visit type */}
          <div className="mb-8">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900"><span className="rounded-full bg-teal-600 px-2.5 py-0.5 text-xs font-bold text-white">2</span> Visit Type</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              {[
                { key: "in-person", label: "In-Person Visit", desc: "At hospital", icon: IconStethoscope },
                { key: "video", label: "Video Consult", desc: "From home", icon: IconVideo },
                { key: "home", label: "Home Visit", desc: "Doctor comes", icon: IconMapPin },
              ].map((t) => (
                <button
                  key={t.key}
                  onClick={() => setVisitType(t.key)}
                  className={`flex items-center gap-3 rounded-xl border p-4 text-left transition-colors ${
                    visitType === t.key ? "border-teal-600 bg-teal-50" : "border-slate-200 hover:border-teal-200"
                  }`}
                >
                  <t.icon className="h-6 w-6 text-teal-600" />
                  <div>
                    <p className="font-semibold text-slate-900">{t.label}</p>
                    <p className="text-xs text-slate-500">{t.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 3: date & slot */}
          <div className="mb-8">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900"><span className="rounded-full bg-teal-600 px-2.5 py-0.5 text-xs font-bold text-white">3</span> Date & Time</h2>
            <div className="mt-4 grid grid-cols-7 gap-2">
              {dates.map((d, i) => (
                <button
                  key={d.date}
                  onClick={() => setDateIndex(i)}
                  className={`rounded-xl border py-3 text-center transition-colors ${
                    dateIndex === i ? "border-teal-600 bg-teal-50" : "border-slate-200 hover:border-teal-200"
                  }`}
                >
                  <p className="text-xs font-medium text-slate-500">{d.label}</p>
                  <p className="text-xl font-bold text-slate-900">{d.day}</p>
                </button>
              ))}
            </div>
            <div className="mt-4 grid grid-cols-4 gap-2 sm:grid-cols-8">
              {slots.map((slot) => (
                <button
                  key={slot}
                  onClick={() => setSelectedSlot(slot)}
                  className={`rounded-lg border py-2 text-xs font-semibold transition-colors ${
                    selectedSlot === slot ? "border-teal-600 bg-teal-600 text-white" : "border-slate-200 text-slate-700 hover:border-teal-300"
                  }`}
                >
                  {slot}
                </button>
              ))}
            </div>
          </div>

          {/* Step 4: symptoms */}
          <div className="mb-8">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900"><span className="rounded-full bg-teal-600 px-2.5 py-0.5 text-xs font-bold text-white">4</span> Reason for Visit</h2>
            <textarea
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              placeholder="Describe your symptoms or reason for consultation..."
              rows={3}
              className="mt-4 w-full rounded-xl border border-slate-200 p-4 text-sm outline-none focus:border-teal-400"
            />
          </div>

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={!selectedDoctor || !selectedSlot}
            className="w-full rounded-xl bg-teal-600 py-4 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-teal-700 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400"
          >
            Confirm Appointment
          </button>
          <p className="mt-3 text-center text-xs text-slate-400">
            {activeDoctor && selectedSlot ? `You're booking ${activeDoctor.name} on ${dates[dateIndex].date} at ${selectedSlot}.` : "Select a doctor and time slot to continue."}
          </p>
        </div>
      </section>
    </div>
  );
}
