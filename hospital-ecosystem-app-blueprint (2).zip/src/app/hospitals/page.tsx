"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import { IconMapPin, IconPhone, IconClock, IconBed, IconShield, IconActivity, IconArrowRight } from "@/components/icons";
import Link from "next/link";

interface Hospital {
  id: number;
  name: string;
  code: string;
  address: string;
  city: string;
  state: string;
  phone: string;
  email: string;
  operatingHours: string;
  emergency24x7: boolean;
  beds: number;
  icuBeds: number;
  accreditations: string;
  departmentCount: number;
  doctorCount: number;
}

export default function HospitalsPage() {
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/hospitals");
        setHospitals(await res.json());
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <section className="border-b border-slate-200 bg-gradient-to-br from-white to-teal-50 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold tracking-tight text-slate-900">Our Hospitals & Centres of Excellence</h1>
          <p className="mt-3 max-w-2xl text-lg text-slate-600">
            Three state-of-the-art medical campuses serving communities across India — with 24×7 emergency, ICU, and advanced surgical capabilities.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        {loading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => <div key={i} className="h-72 animate-pulse rounded-2xl bg-slate-100" />)}
          </div>
        ) : (
          <div className="space-y-6">
            {hospitals.map((h) => (
              <div key={h.id} className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div className="grid lg:grid-cols-3">
                  <div className="flex flex-col justify-center bg-gradient-to-br from-teal-700 to-emerald-800 p-8 text-white">
                    <span className="text-xs font-medium uppercase tracking-wider text-teal-200">MedVerse · {h.code}</span>
                    <h2 className="mt-2 text-2xl font-bold">{h.name}</h2>
                    <div className="mt-4 flex items-start gap-2 text-sm text-teal-50">
                      <IconMapPin className="mt-0.5 h-4 w-4 shrink-0" />
                      <span>{h.address}, {h.city}, {h.state}</span>
                    </div>
                    <div className="mt-2 flex items-center gap-2 text-sm text-teal-50">
                      <IconPhone className="h-4 w-4 shrink-0" />
                      <span>{h.phone}</span>
                    </div>
                  </div>
                  <div className="p-8 lg:col-span-2">
                    <div className="flex flex-wrap items-center gap-2">
                      {h.emergency24x7 && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-3 py-1 text-xs font-semibold text-red-600">
                          <IconActivity className="h-3.5 w-3.5" /> 24×7 Emergency
                        </span>
                      )}
                      <span className="inline-flex items-center gap-1 rounded-full bg-teal-50 px-3 py-1 text-xs font-semibold text-teal-600">
                        <IconBed className="h-3.5 w-3.5" /> {h.beds} Beds · {h.icuBeds} ICU
                      </span>
                      <span className="inline-flex items-center gap-1 rounded-full bg-purple-50 px-3 py-1 text-xs font-semibold text-purple-600">
                        <IconShield className="h-3.5 w-3.5" /> {h.accreditations}
                      </span>
                    </div>

                    <div className="mt-6 grid grid-cols-3 gap-4">
                      <div className="rounded-xl bg-slate-50 p-4 text-center">
                        <p className="text-2xl font-bold text-slate-900">{h.departmentCount}</p>
                        <p className="mt-1 text-xs text-slate-500">Departments</p>
                      </div>
                      <div className="rounded-xl bg-slate-50 p-4 text-center">
                        <p className="text-2xl font-bold text-slate-900">{h.doctorCount}</p>
                        <p className="mt-1 text-xs text-slate-500">Specialists</p>
                      </div>
                      <div className="rounded-xl bg-slate-50 p-4 text-center">
                        <p className="text-2xl font-bold text-slate-900">24/7</p>
                        <p className="mt-1 text-xs text-slate-500">Operating</p>
                      </div>
                    </div>

                    <div className="mt-6 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-sm text-slate-500">
                        <IconClock className="h-4 w-4" />
                        {h.operatingHours}
                      </div>
                      <Link href="/doctors" className="inline-flex items-center gap-1.5 rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-teal-700">
                        Find Doctors Here <IconArrowRight className="h-4 w-4" />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
