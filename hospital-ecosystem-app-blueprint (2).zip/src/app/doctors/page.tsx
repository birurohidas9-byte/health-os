"use client";

import { useEffect, useMemo, useState } from "react";
import Navbar from "@/components/Navbar";
import { IconSearch, IconStar, IconVideo, IconMapPin, IconStethoscope, IconCalendar, IconArrowRight } from "@/components/icons";
import Link from "next/link";

interface Doctor {
  id: number;
  name: string;
  specialization: string;
  qualifications: string;
  yearsOfExperience: number;
  consultationFee: string;
  videoConsultFee: string;
  rating: number;
  ratingCount: number;
  bio: string;
  languages: string;
  availableToday: boolean;
  videoConsultAvailable: boolean;
  homeVisitAvailable: boolean;
  acceptsInsurance: boolean;
  departmentName: string;
  hospitalName: string;
  hospitalCity: string;
}

interface Department {
  id: number;
  name: string;
  code: string;
  doctorCount: number;
}

export default function DoctorsPage() {
  const [search, setSearch] = useState("");
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedSpecialty, setSelectedSpecialty] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [dr, dep] = await Promise.all([
          fetch("/api/doctors").then((r) => r.json()),
          fetch("/api/departments").then((r) => r.json()),
        ]);
        setDoctors(dr);
        setDepartments(dep);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const filtered = useMemo(() => {
    return doctors.filter((d) => {
      const matchesSearch =
        !search ||
        d.name.toLowerCase().includes(search.toLowerCase()) ||
        d.specialization.toLowerCase().includes(search.toLowerCase()) ||
        d.hospitalName?.toLowerCase().includes(search.toLowerCase());
      const matchesSpec = !selectedSpecialty || d.specialization.toLowerCase().includes(selectedSpecialty.toLowerCase());
      return matchesSearch && matchesSpec;
    });
  }, [doctors, search, selectedSpecialty]);

  return (
    <div className="min-h-screen">
      <Navbar />

      <section className="border-b border-slate-200 bg-gradient-to-br from-white to-teal-50 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h1 className="text-4xl font-bold tracking-tight text-slate-900">Find a Specialist</h1>
            <p className="mt-3 text-lg text-slate-600">
              Search by name, specialty, or symptom. Book in-person or video visits with trusted experts.
            </p>
          </div>
          <div className="mt-8 flex flex-col gap-4 sm:flex-row">
            <div className="flex flex-1 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
              <IconSearch className="h-5 w-5 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search doctors, specialties, hospitals..."
                className="w-full bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400"
              />
            </div>
            <button className="rounded-xl bg-teal-600 px-8 py-3 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-teal-700">
              Search
            </button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedSpecialty("")}
            className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
              selectedSpecialty === "" ? "border-teal-600 bg-teal-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-teal-300"
            }`}
          >
            All
          </button>
          {departments.map((d) => (
            <button
              key={d.id}
              onClick={() => setSelectedSpecialty(selectedSpecialty === d.name ? "" : d.name)}
              className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
                selectedSpecialty === d.name ? "border-teal-600 bg-teal-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-teal-300"
              }`}
            >
              {d.name}
            </button>
          ))}
        </div>

        {/* Featured doctors */}
        <div className="mt-4 flex items-center gap-2 text-sm text-red-500">
          <IconVideo className="h-4 w-4" />
          <span className="font-medium">Now booking video consults</span>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
        {loading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-80 animate-pulse rounded-2xl bg-slate-100" />
            ))}
          </div>
        ) : (
          <>
            <p className="mb-6 text-sm text-slate-500">{filtered.length} doctor{filtered.length !== 1 ? "s" : ""} available</p>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filtered.map((doc) => (
                <div key={doc.id} className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition-all hover:shadow-lg">
                  <div className="flex items-start gap-4">
                    <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-600 text-xl font-bold text-white shadow-md">
                      {doc.name.replace("Dr. ", "").split(" ").map((w) => w[0]).slice(0, 2).join("")}
                    </div>
                    <div className="min-w-0">
                      <h3 className="truncate text-lg font-semibold text-slate-900">{doc.name}</h3>
                      <p className="text-sm font-medium text-teal-600">{doc.specialization}</p>
                      <p className="mt-0.5 text-xs text-slate-400">{doc.qualifications}</p>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center gap-2">
                    <div className="flex items-center gap-1 rounded-lg bg-emerald-50 px-2 py-1">
                      <IconStar className="h-3.5 w-3.5 text-amber-500" />
                      <span className="text-sm font-semibold text-slate-900">{doc.rating ?? "—"}</span>
                    </div>
                    <span className="text-xs text-slate-500">{doc.ratingCount} reviews</span>
                    <span className="ml-auto text-xs font-medium text-slate-500">{doc.yearsOfExperience} yrs exp</span>
                  </div>

                  <div className="mt-4 space-y-1.5 text-sm text-slate-600">
                    <div className="flex items-center gap-2">
                      <IconStethoscope className="h-4 w-4 text-slate-400" />
                      {doc.departmentName ?? doc.specialization}
                    </div>
                    <div className="flex items-center gap-2">
                      <IconMapPin className="h-4 w-4 text-slate-400" />
                      {doc.hospitalName} · {doc.hospitalCity}
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    {doc.availableToday && (
                      <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-600">Available today</span>
                    )}
                    {doc.videoConsultAvailable && (
                      <span className="rounded-full bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-600">Video consult</span>
                    )}
                    {doc.acceptsInsurance && (
                      <span className="rounded-full bg-purple-50 px-2.5 py-1 text-xs font-medium text-purple-600">Insurance accepted</span>
                    )}
                  </div>

                  <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4">
                    <div>
                      <p className="text-sm font-bold text-slate-900">₹{doc.consultationFee}</p>
                      <p className="text-xs text-slate-400">Consultation</p>
                    </div>
                    <Link
                      href={`/doctors/${doc.id}`}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-teal-700"
                    >
                      <IconCalendar className="h-4 w-4" /> Book
                    </Link>
                  </div>
                </div>
              ))}
            </div>
            {filtered.length === 0 && (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
                <IconSearch className="mx-auto h-10 w-10 text-slate-300" />
                <h3 className="mt-4 text-lg font-semibold text-slate-700">No doctors found</h3>
                <p className="mt-2 text-sm text-slate-500">Try adjusting your search or filters.</p>
              </div>
            )}
          </>
        )}
      </section>
    </div>
  );
}
