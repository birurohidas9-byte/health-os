"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import {
  IconStar, IconVideo, IconMapPin, IconStethoscope, IconShield,
  IconClock, IconLanguages, IconCheckCircle, IconBadge,
} from "@/components/icons";

interface DoctorDetail {
  id: number;
  name: string;
  email: string;
  phone: string;
  specialization: string;
  qualifications: string;
  yearsOfExperience: number;
  consultationFee: string;
  videoConsultFee: string;
  rating: number;
  ratingCount: number;
  bio: string;
  languages: string;
  availableToday: boolean;
  videoConsultAvailable: boolean;
  homeVisitAvailable: boolean;
  acceptsInsurance: boolean;
  departmentName: string;
  departmentCode: string;
  hospitalName: string;
  hospitalCity: string;
  hospitalAddress: string;
  availableSlots: string[];
}

export default function DoctorDetailPage() {
  const params = useParams<{ id: string }>();
  const [doctor, setDoctor] = useState<DoctorDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedSlot, setSelectedSlot] = useState("");
  const [visitType, setVisitType] = useState("in-person");
  const [dateIndex, setDateIndex] = useState(0);
  const [booked, setBooked] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch(`/api/doctors/${params.id}`);
        const data = await res.json();
        setDoctor(data);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [params.id]);

  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() + i * 86400000);
    return {
      label: i === 0 ? "Today" : d.toLocaleDateString("en-IN", { weekday: "short" }),
      date: d.toISOString().split("T")[0],
      day: d.getDate(),
    };
  });

  if (loading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="h-96 animate-pulse rounded-2xl bg-slate-100" />
        </div>
      </div>
    );
  }

  if (!doctor) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="mx-auto max-w-7xl px-4 py-16 text-center sm:px-6 lg:px-8">
          <p className="text-slate-600">Doctor not found.</p>
        </div>
      </div>
    );
  }

  const handleBook = async () => {
    if (!selectedSlot) return;
    // Use patient 1 (Rahul) as the demo patient
    const res = await fetch("/api/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        patientId: 1,
        doctorId: doctor.id,
        appointmentDate: dates[dateIndex].date,
        timeSlot: selectedSlot,
        visitType,
        symptoms: "",
        paymentMethod: visitType === "video" ? "online" : "hospital",
        amount: visitType === "video" ? doctor.videoConsultFee : doctor.consultationFee,
      }),
    });
    const data = await res.json();
    if (data.success) {
      setBooked(true);
    }
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        {booked ? (
          <div className="mx-auto max-w-lg rounded-2xl border border-emerald-200 bg-emerald-50 p-10 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500 text-white">
              <IconCheckCircle className="h-8 w-8" />
            </div>
            <h2 className="text-2xl font-bold text-emerald-900">Appointment Booked!</h2>
            <p className="mt-3 text-emerald-700">
              Your appointment with {doctor.name} has been confirmed for {dates[dateIndex].date} at {selectedSlot}.
            </p>
            <p className="mt-2 text-sm text-emerald-600">
              Check your Patient Portal for booking details and QR code.
            </p>
          </div>
        ) : (
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Doctor profile */}
            <div className="lg:col-span-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
                <div className="flex flex-wrap items-start gap-6">
                  <div className="flex h-24 w-24 shrink-0 items-center justify-center rounded-3xl bg-gradient-to-br from-teal-500 to-emerald-600 text-3xl font-bold text-white shadow-lg">
                    {doctor.name.replace("Dr. ", "").split(" ").map((w) => w[0]).slice(0, 2).join("")}
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold tracking-tight text-slate-900">{doctor.name}</h1>
                    <p className="mt-1 text-lg font-medium text-teal-600">{doctor.specialization}</p>
                    <p className="mt-1 text-sm text-slate-500">{doctor.qualifications}</p>
                    <div className="mt-3 flex flex-wrap items-center gap-3">
                      <div className="flex items-center gap-1 rounded-lg bg-emerald-50 px-2.5 py-1.5">
                        <IconStar className="h-4 w-4 text-amber-500" />
                        <span className="font-semibold text-slate-900">{doctor.rating}</span>
                        <span className="text-xs text-slate-500">({doctor.ratingCount} reviews)</span>
                      </div>
                      <span className="text-sm text-slate-600">{doctor.yearsOfExperience} years experience</span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3">
                    <IconStethoscope className="h-5 w-5 text-teal-600" />
                    <div className="text-sm">
                      <p className="text-xs text-slate-500">Department</p>
                      <p className="font-medium text-slate-900">{doctor.departmentName ?? doctor.specialization}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3">
                    <IconMapPin className="h-5 w-5 text-teal-600" />
                    <div className="text-sm">
                      <p className="text-xs text-slate-500">Hospital</p>
                      <p className="font-medium text-slate-900">{doctor.hospitalName}, {doctor.hospitalCity}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3">
                    <IconLanguages className="h-5 w-5 text-teal-600" />
                    <div className="text-sm">
                      <p className="text-xs text-slate-500">Languages</p>
                      <p className="font-medium text-slate-900">{doctor.languages}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3">
                    <IconShield className="h-5 w-5 text-teal-600" />
                    <div className="text-sm">
                      <p className="text-xs text-slate-500">Insurance</p>
                      <p className="font-medium text-slate-900">{doctor.acceptsInsurance ? "Accepted" : "Not accepted"}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <h3 className="font-semibold text-slate-900">About {doctor.name}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{doctor.bio || `${doctor.name} is an experienced specialist with ${doctor.yearsOfExperience} years in ${doctor.specialization}.`}</p>
                </div>

                <div className="mt-6">
                  <h3 className="font-semibold text-slate-900">Certifications & Registrations</h3>
                  <div className="mt-2 space-y-2 text-sm text-slate-600">
                    <div className="flex items-center gap-2">
                      <IconBadge className="h-4 w-4 text-teal-500" />
                      Medical Registration: REG-{doctor.id * 1001}
                    </div>
                    <div className="flex items-center gap-2">
                      <IconBadge className="h-4 w-4 text-teal-500" />
                      Member, {doctor.specialization} Association of India
                    </div>
                  </div>
                </div>
              </div>

              {/* Reviews placeholder */}
              <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
                <h3 className="font-semibold text-slate-900">What Patients Say</h3>
                <div className="mt-4 space-y-4">
                  {[
                    { name: "Suresh Kumar", rating: 5, comment: `Very thorough consultation. ${doctor.name} explained everything clearly.`, date: "2 weeks ago" },
                    { name: "Meera S", rating: 5, comment: "Excellent doctor, minimal waiting time and great facilities.", date: "1 month ago" },
                  ].map((r) => (
                    <div key={r.name} className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-slate-900">{r.name}</p>
                        <div className="flex gap-0.5">
                          {Array.from({ length: r.rating }).map((_, i) => (
                            <IconStar key={i} className="h-3.5 w-3.5 text-amber-400" />
                          ))}
                        </div>
                      </div>
                      <p className="mt-2 text-sm text-slate-600">{r.comment}</p>
                      <p className="mt-1 text-xs text-slate-400">{r.date}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Booking panel */}
            <div className="lg:col-span-1">
              <div className="sticky top-20 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-slate-900">Book Appointment</h3>

                <div className="mt-4">
                  <p className="text-sm font-medium text-slate-700">Visit Type</p>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {[
                      { key: "in-person", label: "In-Person", fee: doctor.consultationFee },
                      { key: "video", label: "Video", fee: doctor.videoConsultFee },
                      { key: "home", label: "Home Visit", fee: (Number(doctor.consultationFee) * 2).toString() },
                    ].map((t) => (
                      <button
                        key={t.key}
                        onClick={() => setVisitType(t.key)}
                        className={`rounded-xl border p-3 text-center transition-colors ${
                          visitType === t.key ? "border-teal-600 bg-teal-50" : "border-slate-200 hover:border-teal-200"
                        }`}
                      >
                        <div className="flex items-center justify-center gap-1">
                          {t.key === "video" && <IconVideo className="h-4 w-4 text-teal-600" />}
                          {t.key === "in-person" && <IconStethoscope className="h-4 w-4 text-teal-600" />}
                          {t.key === "home" && <IconMapPin className="h-4 w-4 text-teal-600" />}
                        </div>
                        <p className="mt-1 text-xs font-medium text-slate-900">{t.label}</p>
                        <p className="text-xs text-slate-500">₹{t.fee}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-5">
                  <p className="text-sm font-medium text-slate-700">Select Date</p>
                  <div className="mt-2 grid grid-cols-7 gap-1.5">
                    {dates.map((d, i) => (
                      <button
                        key={d.date}
                        onClick={() => setDateIndex(i)}
                        className={`rounded-lg border py-2 text-center transition-colors ${
                          dateIndex === i ? "border-teal-600 bg-teal-50" : "border-slate-200 hover:border-teal-200"
                        }`}
                      >
                        <p className="text-[10px] font-medium text-slate-500">{d.label}</p>
                        <p className={`text-sm font-bold ${dateIndex === i ? "text-teal-700" : "text-slate-900"}`}>{d.day}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-5">
                  <p className="text-sm font-medium text-slate-700">Select Slot</p>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {(doctor.availableSlots ?? []).map((slot) => (
                      <button
                        key={slot}
                        onClick={() => setSelectedSlot(slot)}
                        className={`rounded-lg border py-2 text-xs font-medium transition-colors ${
                          selectedSlot === slot ? "border-teal-600 bg-teal-600 text-white" : "border-slate-200 text-slate-700 hover:border-teal-300"
                        }`}
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-6 space-y-2 border-t border-slate-100 pt-4 text-sm">
                  <div className="flex items-center justify-between text-slate-600">
                    <span>Consultation Fee</span>
                    <span className="font-semibold text-slate-900">₹{visitType === "video" ? doctor.videoConsultFee : visitType === "home" ? Number(doctor.consultationFee) * 2 : doctor.consultationFee}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-600">
                    <span>Service Tax (18%)</span>
                    <span className="font-semibold text-slate-900">₹{(Number(visitType === "video" ? doctor.videoConsultFee : doctor.consultationFee) * 0.18).toFixed(0)}</span>
                  </div>
                  <div className="flex items-center justify-between border-t border-slate-100 pt-3 text-base">
                    <span className="font-medium text-slate-900">Total</span>
                    <span className="text-lg font-bold text-teal-700">₹{(Number(visitType === "video" ? doctor.videoConsultFee : visitType === "home" ? Number(doctor.consultationFee) * 2 : doctor.consultationFee) * 1.18).toFixed(0)}</span>
                  </div>
                </div>

                <button
                  onClick={handleBook}
                  disabled={!selectedSlot}
                  className="mt-6 w-full rounded-xl bg-teal-600 py-3.5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-teal-700 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400"
                >
                  {selectedSlot ? `Confirm Booking · ${selectedSlot}` : "Select a time slot"}
                </button>
                <p className="mt-3 flex items-center justify-center gap-1 text-xs text-slate-400">
                  <IconClock className="h-3.5 w-3.5" /> Free cancellation up to 2 hours before
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
