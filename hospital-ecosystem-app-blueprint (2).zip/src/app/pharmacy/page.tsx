"use client";

import { useEffect, useMemo, useState } from "react";
import Navbar from "@/components/Navbar";
import { IconSearch, IconPill, IconPlus, IconShoppingCart, IconCamera } from "@/components/icons";

interface Medicine {
  id: number;
  name: string;
  brand: string;
  genericName: string;
  manufacturer: string;
  category: string;
  price: string;
  requiresPrescription: boolean;
  stockQuantity: number;
  description: string;
}

export default function PharmacyPage() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<Record<number, number>>({});
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/medicines");
        setMedicines(await res.json());
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const filtered = useMemo(() => {
    return medicines.filter(
      (m) =>
        !search ||
        m.name.toLowerCase().includes(search.toLowerCase()) ||
        m.brand?.toLowerCase().includes(search.toLowerCase()) ||
        m.genericName?.toLowerCase().includes(search.toLowerCase()) ||
        m.category?.toLowerCase().includes(search.toLowerCase())
    );
  }, [medicines, search]);

  const cartTotal = Object.entries(cart).reduce((sum, [id, qty]) => {
    const med = medicines.find((m) => m.id === Number(id));
    return sum + (med ? Number(med.price) * qty : 0);
  }, 0);

  const cartItems = Object.entries(cart).filter(([, qty]) => qty > 0);
  const cartCount = cartItems.reduce((s, [, q]) => s + q, 0);

  const addToCart = (id: number) => setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
  const removeFromCart = (id: number) => setCart((c) => ({ ...c, [id]: Math.max(0, (c[id] ?? 0) - 1) }));

  return (
    <div className="min-h-screen">
      <Navbar />

      <section className="border-b border-slate-200 bg-gradient-to-br from-amber-50 to-white py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <h1 className="text-4xl font-bold tracking-tight text-slate-900">MedVerse Pharmacy</h1>
              <p className="mt-3 max-w-xl text-lg text-slate-600">
                Genuine medicines at transparent prices. Express delivery within your city.
              </p>
            </div>
            <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-100 text-amber-600">
                <IconShoppingCart className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-900">{cartCount} item{cartCount !== 1 ? "s" : ""}</p>
                <p className="text-xs text-slate-500">Cart total: ₹{cartTotal.toFixed(0)}</p>
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <div className="flex flex-1 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
              <IconSearch className="h-5 w-5 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by medicine name, brand, or salt..."
                className="w-full bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400"
              />
            </div>
            <button className="inline-flex items-center justify-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-6 py-3 text-sm font-semibold text-amber-700 transition-colors hover:bg-amber-100">
              <IconCamera className="h-5 w-5" /> Upload Prescription
            </button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            {loading ? (
              <div className="grid gap-4 sm:grid-cols-2">
                {[1, 2, 3].map((i) => <div key={i} className="h-40 animate-pulse rounded-xl bg-slate-100" />)}
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                {filtered.map((med) => (
                  <div key={med.id} className="flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-shadow hover:shadow-md">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-50 text-teal-600">
                          <IconPill className="h-6 w-6" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900">{med.brand || med.name}</h3>
                          <p className="text-xs text-slate-500">{med.genericName}</p>
                        </div>
                      </div>
                      {med.requiresPrescription && (
                        <span className="rounded-full bg-red-50 px-2 py-0.5 text-[10px] font-bold text-red-500">RX</span>
                      )}
                    </div>
                    <p className="mt-2 text-xs text-slate-500">{med.description}</p>
                    <div className="mt-2 flex items-center text-xs">
                      <span className="rounded bg-slate-100 px-2 py-0.5 text-slate-600">{med.category}</span>
                      <span className="ml-2 text-slate-400">{med.manufacturer}</span>
                    </div>
                    <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
                      <div>
                        <p className="text-lg font-bold text-slate-900">₹{med.price}</p>
                        <p className="text-[10px] text-emerald-600">Indicative · incl. taxes</p>
                      </div>
                      {cart[med.id] ? (
                        <div className="flex items-center gap-2">
                          <button onClick={() => removeFromCart(med.id)} className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50">−</button>
                          <span className="w-6 text-center font-semibold text-slate-900">{cart[med.id]}</span>
                          <button onClick={() => addToCart(med.id)} className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50">+</button>
                        </div>
                      ) : (
                        <button
                          onClick={() => addToCart(med.id)}
                          className="inline-flex items-center gap-1 rounded-lg bg-teal-600 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-700"
                        >
                          <IconPlus className="h-3.5 w-3.5" /> Add
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Cart sidebar */}
          <div>
            <div className="sticky top-20 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-slate-900">Your Order</h3>
              {orderPlaced ? (
                <div className="mt-6 text-center">
                  <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-2xl text-white">✓</div>
                  <h4 className="font-semibold text-slate-900">Order Placed!</h4>
                  <p className="mt-2 text-sm text-slate-500">
                    Your medicines will be delivered within 2 hours. Pharmacist will verify your order shortly.
                  </p>
                  <button
                    onClick={() => { setOrderPlaced(false); setCart({}); }}
                    className="mt-4 w-full rounded-lg border border-teal-600 py-2 text-sm font-semibold text-teal-600 hover:bg-teal-50"
                  >
                    Order Again
                  </button>
                </div>
              ) : cartItems.length === 0 ? (
                <div className="mt-6 py-10 text-center">
                  <IconShoppingCart className="mx-auto h-10 w-10 text-slate-200" />
                  <p className="mt-3 text-sm text-slate-500">Your cart is empty. Add some medicines.</p>
                </div>
              ) : (
                <>
                  <div className="mt-4 space-y-3">
                    {cartItems.map(([id, qty]) => {
                      const med = medicines.find((m) => m.id === Number(id));
                      if (!med) return null;
                      return (
                        <div key={id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium text-slate-900">{med.brand || med.name}</p>
                            <p className="text-xs text-slate-500">Qty: {qty}</p>
                          </div>
                          <p className="text-sm font-semibold text-slate-900">₹{(Number(med.price) * qty).toFixed(0)}</p>
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-4 space-y-1.5 border-t border-slate-100 pt-4 text-sm">
                    <div className="flex justify-between text-slate-600"><span>Subtotal</span><span className="font-medium">₹{cartTotal.toFixed(0)}</span></div>
                    <div className="flex justify-between text-slate-600"><span>Delivery</span><span className="text-emerald-600 font-medium">FREE</span></div>
                    <div className="flex justify-between border-t border-slate-100 pt-2 text-base">
                      <span className="font-semibold text-slate-900">Total</span>
                      <span className="font-bold text-teal-700">₹{cartTotal.toFixed(0)}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setOrderPlaced(true)}
                    className="mt-5 w-full rounded-xl bg-teal-600 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-700"
                  >
                    Place Order
                  </button>
                  <p className="mt-2 flex items-center justify-center gap-1 text-xs text-slate-400">
                    <IconPill className="h-3.5 w-3.5" /> Express delivery in {cartCount > 0 ? "30 min" : "—"}
                  </p>
                </>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
