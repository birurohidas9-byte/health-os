import { NextResponse } from "next/server";
import { db } from "@/db";
import { hospitals, departments, doctors } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const result = await db
      .select({
        id: hospitals.id,
        name: hospitals.name,
        code: hospitals.code,
        address: hospitals.address,
        city: hospitals.city,
        state: hospitals.state,
        country: hospitals.country,
        phone: hospitals.phone,
        email: hospitals.email,
        operatingHours: hospitals.operatingHours,
        emergency24x7: hospitals.emergency24x7,
        beds: hospitals.beds,
        icuBeds: hospitals.icuBeds,
        accreditations: hospitals.accreditations,
        departmentCount: sql<number>`(select count(*)::int from departments d where d.hospital_id = ${hospitals.id})`,
        doctorCount: sql<number>`(select count(*)::int from doctors dc where dc.hospital_id = ${hospitals.id})`,
      })
      .from(hospitals)
      .where(sql`${hospitals.isActive} = true`);

    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
