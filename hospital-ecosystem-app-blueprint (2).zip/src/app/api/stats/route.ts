import { NextResponse } from "next/server";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import {
  patients,
  doctors,
  appointments,
  hospitals,
  departments,
  invoices,
  prescriptions,
  labOrders,
  medicines,
  labTests,
} from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [
      patientCount,
      doctorCount,
      appointmentCount,
      hospitalCount,
      departmentCount,
      revenue,
      completedAppointments,
      pendingAppointments,
      medicineCount,
      labTestCount,
      prescriptionCount,
      newPatientsToday,
      pendingLabOrders,
    ] = await Promise.all([
      db.select({ c: sql<number>`count(*)::int` }).from(patients),
      db.select({ c: sql<number>`count(*)::int` }).from(doctors),
      db.select({ c: sql<number>`count(*)::int` }).from(appointments),
      db.select({ c: sql<number>`count(*)::int` }).from(hospitals),
      db.select({ c: sql<number>`count(*)::int` }).from(departments),
      db
        .select({
          total: sql<string>`coalesce(sum(${invoices.totalAmount}), 0)`,
        })
        .from(invoices)
        .where(sql`${invoices.status} = 'paid'`),
      db.select({ c: sql<number>`count(*)::int` }).from(appointments).where(sql`${appointments.status} = 'completed'`),
      db.select({ c: sql<number>`count(*)::int` }).from(appointments).where(sql`${appointments.status} = 'pending'`),
      db.select({ c: sql<number>`count(*)::int` }).from(medicines),
      db.select({ c: sql<number>`count(*)::int` }).from(labTests),
      db.select({ c: sql<number>`count(*)::int` }).from(prescriptions),
      db.select({ c: sql<number>`count(*)::int` }).from(patients).where(sql`${patients.createdAt}::date = CURRENT_DATE`),
      db.select({ c: sql<number>`count(*)::int` }).from(labOrders).where(sql`${labOrders.status} != 'reported'`),
    ]);

    const totalRevenue = Number(revenue[0]?.total ?? 0);

    return NextResponse.json({
      patients: patientCount[0]?.c ?? 0,
      doctors: doctorCount[0]?.c ?? 0,
      appointments: appointmentCount[0]?.c ?? 0,
      hospitals: hospitalCount[0]?.c ?? 0,
      departments: departmentCount[0]?.c ?? 0,
      totalRevenue,
      completedAppointments: completedAppointments[0]?.c ?? 0,
      pendingAppointments: pendingAppointments[0]?.c ?? 0,
      medicines: medicineCount[0]?.c ?? 0,
      labTests: labTestCount[0]?.c ?? 0,
      prescriptions: prescriptionCount[0]?.c ?? 0,
      newPatientsToday: newPatientsToday[0]?.c ?? 0,
      pendingLabOrders: pendingLabOrders[0]?.c ?? 0,
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Stats server error" },
      { status: 500 }
    );
  }
}
