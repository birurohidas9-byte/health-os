import { db } from "@/db";
import {
  users,
  hospitals,
  departments,
  doctors,
  patients,
  medicines,
  labTests,
  healthPackages,
  articles,
  appointments,
  invoices,
} from "@/db/schema";
import { sql } from "drizzle-orm";
import { hash } from "crypto";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    // Check if already seeded
    const existing = await db.select({ count: sql<number>`count(*)::int` }).from(hospitals);
    const hospitalCount = existing[0]?.count ?? 0;
    if (hospitalCount > 0) {
      return new Response(JSON.stringify({ message: "Database already seeded", count: hospitalCount }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }

    // ─── Admin User ───
    await db.insert(users).values([
      {
        name: "Dr. Vishal Sharma",
        email: "admin@medverse.com",
        phone: "+91 98765 43210",
        passwordHash: "admin-demo",
        role: "admin",
      },
      {
        name: "Rahul Khanna",
        email: "rahul@patient.com",
        phone: "+91 90000 11111",
        passwordHash: "patient-demo",
        role: "patient",
      },
      {
        name: "Priya Deshmukh",
        email: "priya@patient.com",
        phone: "+91 90000 22222",
        passwordHash: "patient-demo",
        role: "patient",
      },
    ]);

    // Admin user id is 1, patients 2, 3
    const patientAdmin = await db.select({ id: users.id }).from(users).where(sql`${users.email} = 'admin@medverse.com'`);
    const patientRahul = await db.select({ id: users.id }).from(users).where(sql`${users.email} = 'rahul@patient.com'`);
    const patientPriya = await db.select({ id: users.id }).from(users).where(sql`${users.email} = 'priya@patient.com'`);

    // ─── Hospitals ───
    await db.insert(hospitals).values([
      {
        name: "MedVerse Hospital & Research Centre",
        code: "MV-BLR-01",
        address: "24, MG Road, Indiranagar",
        city: "Bengaluru",
        state: "Karnataka",
        country: "India",
        phone: "+91 80 4521 1000",
        email: "care@medverse.in",
        latitude: 12.9716,
        longitude: 77.5946,
        operatingHours: "24 hours • 7 days",
        emergency24x7: true,
        beds: 450,
        icuBeds: 65,
        accreditations: "NABH, JCI, NABL",
      },
      {
        name: "MedVerse Medicity - Delhi NCR",
        code: "MV-ND-02",
        address: "Plot 45, Sector 18, NOIDA",
        city: "Gurugram",
        state: "Haryana",
        country: "India",
        phone: "+91 120 4521 2000",
        email: "ncr@medverse.in",
        latitude: 28.4595,
        longitude: 77.0266,
        operatingHours: "24 hours • 7 days",
        emergency24x7: true,
        beds: 320,
        icuBeds: 48,
        accreditations: "NABH, NABL",
      },
      {
        name: "MedVerse Global Hospital - Mumbai",
        code: "MV-BOM-03",
        address: "A/2, Connaught Place, Andheri West",
        city: "Mumbai",
        state: "Maharashtra",
        country: "India",
        phone: "+91 22 4521 3000",
        email: "mum@medverse.in",
        latitude: 19.1911,
        longitude: 72.8266,
        operatingHours: "24 hours • 7 days",
        emergency24x7: true,
        beds: 280,
        icuBeds: 40,
        accreditations: "NABH, JCI",
      },
    ]);

    const hospitalList = await db.select().from(hospitals);

    // ─── Departments ───
    const deptData = [
      { name: "Cardiology", code: "CARD", icon: "heart", description: "Heart & cardiovascular care with advanced cath lab and cardiac surgery" },
      { name: "Neurology", code: "NEURO", icon: "brain", description: "Brain, spine and nervous system disorders" },
      { name: "Orthopedics", code: "ORTHO", icon: "bone", description: "Bone, joint, spine and sports injuries" },
      { name: "Dermatology", code: "DERM", icon: "skin", description: "Skin, hair and nail disorders" },
      { name: "Gynecology", code: "GYNAE", icon: "female", description: "Women's health, pregnancy and fertility" },
      { name: "Pediatrics", code: "PED", icon: "baby", description: "Child health from newborn to adolescence" },
      { name: "General Medicine", code: "MED", icon: "stethoscope", description: "Comprehensive adult healthcare" },
      { name: "Oncology", code: "ONCO", icon: "dna", description: "Cancer diagnosis, chemotherapy and radiation" },
      { name: "ENT", code: "ENT", icon: "ear", description: "Ear, nose and throat disorders" },
      { name: "Ophthalmology", code: "OPTH", icon: "eye", description: "Eye and vision care" },
      { name: "Endocrinology", code: "ENDO", icon: "droplet", description: "Hormonal and metabolic disorders" },
      { name: "Pulmonology", code: "PULM", icon: "lungs", description: "Respiratory and lung disorders" },
      { name: "Urology", code: "URO", icon: "kidney", description: "Urinary tract and male reproductive disorders" },
      { name: "Gastroenterology", code: "GASTRO", icon: "stomach", description: "Digestive system and liver disorders" },
      { name: "Nephrology", code: "NEPH", icon: "kidney", description: "Kidney diseases and dialysis" },
      { name: "Psychiatry", code: "PSY", icon: "mind", description: "Mental health and psychological well-being" },
      { name: "Physiotherapy", code: "PHYSIO", icon: "activity", description: "Rehabilitation and pain management" },
      { name: "Dental", code: "DENTAL", icon: "tooth", description: "Oral health and dental surgery" },
    ];

    const deptIds: Record<string, number> = {};
    for (const d of deptData) {
      const inserted = await db
        .insert(departments)
        .values({
          ...d,
          hospitalId: hospitalList[0]?.id,
        })
        .returning({ id: departments.id });
      deptIds[d.code] = inserted[0]?.id ?? 0;
    }

    // ─── Doctor users ───
    await db.insert(users).values([
      { name: "Dr. Arjun Mehta", email: "arjun.mehta@medverse.com", role: "doctor", phone: "+91 98100 00001" },
      { name: "Dr. Sneha Reddy", email: "sneha.reddy@medverse.com", role: "doctor", phone: "+91 98100 00002" },
      { name: "Dr. Vikram Nair", email: "vikram.nair@medverse.com", role: "doctor", phone: "+91 98100 00003" },
      { name: "Dr. Anjali Gupta", email: "anjali.gupta@medverse.com", role: "doctor", phone: "+91 98100 00004" },
      { name: "Dr. Ravi Shankar", email: "ravi.shankar@medverse.com", role: "doctor", phone: "+91 98100 00005" },
      { name: "Dr. Karthik Rao", email: "karthik.rao@medverse.com", role: "doctor", phone: "+91 98100 00006" },
      { name: "Dr. Nisha Patel", email: "nisha.patel@medverse.com", role: "doctor", phone: "+91 98100 00007" },
      { name: "Dr. Farhan Ali", email: "farhan.ali@medverse.com", role: "doctor", phone: "+91 98100 00008" },
      { name: "Dr. Rekha Menon", email: "rekha.menon@medverse.com", role: "doctor", phone: "+91 98100 00009" },
      { name: "Dr. Amit Verma", email: "amit.verma@medverse.com", role: "doctor", phone: "+91 98100 00010" },
      { name: "Dr. Suresh Nandakumar", email: "suresh.n@medverse.com", role: "doctor", phone: "+91 98100 00011" },
      { name: "Dr. Pooja Iyer", email: "pooja.iyer@medverse.com", role: "doctor", phone: "+91 98100 00012" },
    ]);

    const getDoctorUserId = async (email: string) => {
      const res = await db.select({ id: users.id }).from(users).where(sql`${users.email} = ${email}`);
      return res[0]?.id;
    };

    // ─── Doctors ───
    const docData = [
      { name: "Dr. Arjun Mehta", email: "arjun.mehta@medverse.com", specs: "MBBS, MD (Cardiology), DM (Interventional Cardiology)", spec: "Cardiology", dept: "CARD", exp: 18, fee: "1200", vfee: "800", rating: 4.8, count: 320, bio: "Renowned interventional cardiologist with 18+ years of experience in complex angioplasties and heart failure management.", lang: "English, Hindi, Kannada" },
      { name: "Dr. Sneha Reddy", email: "sneha.reddy@medverse.com", specs: "MBBS, MD (Dermatology), Fellowship in Cosmetic Dermatology", spec: "Dermatology", dept: "DERM", exp: 12, fee: "900", vfee: "600", rating: 4.7, count: 275, bio: "Specialist in clinical & cosmetic dermatology including laser treatments and scar management.", lang: "English, Telugu, Hindi" },
      { name: "Dr. Vikram Nair", email: "vikram.nair@medverse.com", specs: "MBBS, MS (Orthopedics), MRCS", spec: "Orthopedics", dept: "ORTHO", exp: 22, fee: "1500", vfee: "1000", rating: 4.9, count: 450, bio: "Senior orthopedic surgeon specializing in joint replacement, arthroscopy and sports medicine.", lang: "English, Malayalam, Hindi" },
      { name: "Dr. Anjali Gupta", email: "anjali.gupta@medverse.com", specs: "MBBS, MD (Neurology), DM (Neurology)", spec: "Neurology", dept: "NEURO", exp: 15, fee: "1300", vfee: "900", rating: 4.8, count: 298, bio: "Neurologist expert in stroke management, epilepsy and movement disorders.", lang: "English, Hindi, Punjabi" },
      { name: "Dr. Ravi Shankar", email: "ravi.shankar@medverse.com", specs: "MBBS, MD (General Medicine)", spec: "General Physician", dept: "MED", exp: 10, fee: "600", vfee: "400", rating: 4.5, count: 540, bio: "Primary care physician handling routine & chronic adult health conditions.", lang: "English, Hindi, Tamil" },
      { name: "Dr. Karthik Rao", email: "karthik.rao@medverse.com", specs: "MBBS, DGO, MS (GYN)", spec: "Gynecology & Obstetrics", dept: "GYNAE", exp: 16, fee: "1000", vfee: "700", rating: 4.9, count: 380, bio: "Obstetrician & gynecologist specializing in high-risk pregnancies and minimally invasive surgery.", lang: "English, Kannada, Hindi" },
      { name: "Dr. Nisha Patel", email: "nisha.patel@medverse.com", specs: "MBBS, MD (Pediatrics)", spec: "Pediatrics", dept: "PED", exp: 13, fee: "800", vfee: "550", rating: 4.8, count: 410, bio: "Pediatrician devoted to newborn care, vaccinations and child nutrition.", lang: "English, Hindi, Gujarati" },
      { name: "Dr. Farhan Ali", email: "farhan.ali@medverse.com", specs: "MBBS, MS (ENT)", spec: "ENT", dept: "ENT", exp: 11, fee: "750", vfee: "500", rating: 4.6, count: 260, bio: "Head & neck surgeon handling sinus, tonsil and thyroid disorders.", lang: "English, Hindi, Urdu" },
      { name: "Dr. Rekha Menon", email: "rekha.menon@medverse.com", specs: "MBBS, MD (Ophthalmology), FRCS", spec: "Ophthalmology", dept: "OPTH", exp: 19, fee: "1100", vfee: "750", rating: 4.9, count: 355, bio: "Retina & cataract surgeon with advanced vitrectomy experience.", lang: "English, Malayalam, Hindi" },
      { name: "Dr. Amit Verma", email: "amit.verma@medverse.com", specs: "MBBS, MD (Radiation Oncology)", spec: "Oncology", dept: "ONCO", exp: 14, fee: "1400", vfee: "950", rating: 4.7, count: 210, bio: "Oncologist specializing in precision cancer care and image-guided radiation.", lang: "English, Hindi" },
      { name: "Dr. Suresh Nandakumar", email: "suresh.n@medverse.com", specs: "MBBS, MD (Endocrinology), DM (Endocrinology)", spec: "Endocrinology", dept: "ENDO", exp: 12, fee: "950", vfee: "650", rating: 4.6, count: 240, bio: "Endocrinologist managing diabetes, thyroid and hormonal disorders.", lang: "English, Tamil, Hindi" },
      { name: "Dr. Pooja Iyer", email: "pooja.iyer@medverse.com", specs: "MBBS, MS (Gastroenterology)", spec: "Gastroenterology", dept: "GASTRO", exp: 9, fee: "850", vfee: "550", rating: 4.5, count: 190, bio: "Gastroenterologist handling digestive, liver and gut health problems.", lang: "English, Hindi, Marathi" },
    ];

    for (const [i, d] of docData.entries()) {
      const uid = await getDoctorUserId(d.email);
      await db.insert(doctors).values({
        userId: uid,
        registrationNo: `MVP-100${i + 1}`,
        qualifications: d.specs,
        specialization: d.spec,
        departmentId: deptIds[d.dept],
        hospitalId: hospitalList[i % 3]?.id,
        yearsOfExperience: d.exp,
        consultationFee: d.fee,
        videoConsultFee: d.vfee,
        rating: d.rating,
        ratingCount: d.count,
        bio: d.bio,
        languages: d.lang,
        availableToday: true,
        videoConsultAvailable: true,
        homeVisitAvailable: i % 2 === 0,
        acceptsInsurance: true,
      });
    }

    // ─── Patients detail ───
    await db.insert(patients).values([
      {
        userId: patientRahul[0]?.id,
        medicalId: "MV-PAT-10001",
        bloodGroup: "O+",
        dob: "1992-05-14",
        gender: "Male",
        heightCm: 175,
        weightKg: 78,
        allergies: "Penicillin, Peanuts",
        chronicConditions: "Mild hypertension",
        emergencyContactName: "Sunita Khanna",
        emergencyContactPhone: "+91 91234 56789",
        insuranceProvider: "Star Health",
        insurancePolicyNo: "SH-8845-2019",
        insuranceCoverage: "500000",
        address: "42, Green Park Extension",
        city: "New Delhi",
        state: "Delhi",
        abhaId: "91 9864 3412 5510",
      },
      {
        userId: patientPriya[0]?.id,
        medicalId: "MV-PAT-10002",
        bloodGroup: "A-",
        dob: "1988-11-02",
        gender: "Female",
        heightCm: 162,
        weightKg: 58,
        allergies: "Sulfa drugs",
        chronicConditions: "Hypothyroidism",
        emergencyContactName: "Amit Deshmukh",
        emergencyContactPhone: "+91 90999 12345",
        insuranceProvider: "ICICI Lombard",
        insurancePolicyNo: "ICICI-9921-2021",
        insuranceCoverage: "1000000",
        address: "17, Jubilee Hills",
        city: "Hyderabad",
        state: "Telangana",
      },
    ]);

    // ─── Medicines ───
    await db.insert(medicines).values([
      { name: "Paracetamol 500mg", brand: "Dolo-650", genericName: "Acetaminophen", manufacturer: "Micro Labs", category: "Painkiller", price: "45", requiresPrescription: false, stockQuantity: 500, description: "Fever & pain relief tablet", sideEffects: "Nausea, rash (rare)" },
      { name: "Amoxicillin 500mg", brand: "Amoxil", genericName: "Amoxicillin", manufacturer: "GSK", category: "Antibiotic", price: "120", requiresPrescription: true, stockQuantity: 300, description: "Broad-spectrum antibiotic", sideEffects: "Diarrhea, allergic reactions" },
      { name: "Metformin 500mg", brand: "Glycomet", genericName: "Metformin", manufacturer: "USV", category: "Diabetes", price: "85", requiresPrescription: true, stockQuantity: 400, description: "Oral anti-diabetic", sideEffects: "GI upset, metallic taste" },
      { name: "Amlodipine 5mg", brand: "Amlong", genericName: "Amlodipine", manufacturer: "Micro Labs", category: "Cardiac", price: "95", requiresPrescription: true, stockQuantity: 250, description: "Antihypertensive", sideEffects: "Ankle swelling, headache" },
      { name: "Omeprazole 20mg", brand: "Ocid", genericName: "Omeprazole", manufacturer: "Cipla", category: "Gastro", price: "110", requiresPrescription: true, stockQuantity: 350, description: "Proton pump inhibitor", sideEffects: "Headache, abdominal pain" },
      { name: "Cetirizine 10mg", brand: "Cetzine", genericName: "Cetirizine", manufacturer: "Dr. Reddy's", category: "Antihistamine", price: "55", requiresPrescription: false, stockQuantity: 600, description: "Allergy relief", sideEffects: "Drowsiness, dry mouth" },
      { name: "Vitamin D3 60K", brand: "Upthrive D3", genericName: "Cholecalciferol", manufacturer: "Mankind", category: "Supplement", price: "90", requiresPrescription: false, stockQuantity: 450, description: "Vitamin D supplement", sideEffects: "None significant" },
      { name: "Teleckast 10mg", brand: "Montek", genericName: "Montelukast", manufacturer: "Cipla", category: "Respiratory", price: "135", requiresPrescription: true, stockQuantity: 200, description: "Asthma / allergy relief", sideEffects: "Headache, dizziness" },
    ]);

    // ─── Lab Tests ───
    await db.insert(labTests).values([
      { name: "Complete Blood Count (CBC)", code: "CBC", category: "Blood Test", price: "350", homeCollection: true, preparationInstructions: "No special preparation needed", normalRange: "Varies by component", turnaroundTime: "4-6 hours" },
      { name: "Lipid Profile", code: "LIPID", category: "Cardiac", price: "600", homeCollection: true, preparationInstructions: "Fasting 10-12 hours required", normalRange: "Total Cholesterol < 200 mg/dL", turnaroundTime: "8-12 hours" },
      { name: "Blood Sugar - Fasting", code: "FBS", category: "Diabetes", price: "120", homeCollection: true, preparationInstructions: "Fasting 8-12 hours required", normalRange: "70-100 mg/dL", turnaroundTime: "3 hours" },
      { name: "HbA1c", code: "HBA1C", category: "Diabetes", price: "450", homeCollection: true, preparationInstructions: "No fasting required", normalRange: "< 5.7%", turnaroundTime: "8 hours" },
      { name: "Thyroid Function Test (T3, T4, TSH)", code: "TFT", category: "Thyroid", price: "550", homeCollection: true, preparationInstructions: "No special preparation", normalRange: "TSH 0.4-4.0 mIU/L", turnaroundTime: "6 hours" },
      { name: "Liver Function Test", code: "LFT", category: "Liver", price: "500", homeCollection: true, preparationInstructions: "Fasting 8 hours recommended", normalRange: "Various markers", turnaroundTime: "6 hours" },
      { name: "Kidney Function Test", code: "KFT", category: "Kidney", price: "480", homeCollection: true, preparationInstructions: "Fasting 8 hours recommended", normalRange: "Creatinine 0.6-1.2 mg/dL", turnaroundTime: "6 hours" },
      { name: "Vitamin D (25-OH)", code: "VITD", category: "Hormone", price: "800", homeCollection: true, preparationInstructions: "No fasting required", normalRange: "30-100 ng/mL", turnaroundTime: "12 hours" },
      { name: "Urine Routine & Microscopy", code: "URM", category: "Urine Test", price: "150", homeCollection: true, preparationInstructions: "Mid-stream clean catch sample", normalRange: "No abnormalities", turnaroundTime: "4 hours" },
      { name: "Hb (Hemoglobin)", code: "HB", category: "Blood Test", price: "100", homeCollection: true, preparationInstructions: "No special preparation", normalRange: "13.5-17.5 g/dL (M)", turnaroundTime: "2 hours" },
    ]);

    // ─── Health Packages ───
    await db.insert(healthPackages).values([
      { name: "Basic Health Checkup", description: "Essential screening for early detection", price: "1499", features: { tests: ["CBC", "Blood Sugar", "Lipid Profile", "Urine Analysis"] }, category: "Essential", popular: true },
      { name: "Comprehensive Health Checkup", description: "Complete annual wellness screening", price: "2999", features: { tests: ["CBC", "Lipid Profile", "Liver Function", "Kidney Function", "Thyroid", "HbA1c", "Vitamin D"] }, category: "Comprehensive", popular: true },
      { name: "Executive Health Checkup", description: "Premium preventive health assessment", price: "5999", features: { tests: ["Full Blood Panel", "Advanced Cardiac", "Thyroid", "Cancer Markers", "Vitamin Panel", "Chest X-Ray", "ECG"] }, category: "Executive", popular: false },
      { name: "Women's Health Package", description: "Tailored screening for women", price: "3999", features: { tests: ["CBC", "Thyroid", "Vitamin D", "Pap Smear", "Mammogram", "Bone Density"] }, category: "Gender-Specific", popular: false },
      { name: "Cardiac Care Package", description: "Comprehensive heart health evaluation", price: "4999", features: { tests: ["Lipid Profile", "ECG", "Echo", "TMT", "hs-CRP", "Cardiac Markers"] }, category: "Cardiac", popular: false },
      { name: "Diabetes Care Package", description: "Full diabetes management profile", price: "2499", features: { tests: ["FBS", "PPBS", "HbA1c", "Kidney Function", "Lipid Profile", "Urine Microalbumin"] }, category: "Diabetes", popular: true },
      { name: "Senior Citizen Package", description: "Comprehensive screening for 60+ years", price: "4499", features: { tests: ["Full Blood Panel", "Bone Density", "Vision Test", "Hearing Test", "ECG", "Multiple Specialist Review"] }, category: "Age-Specific", popular: false },
      { name: "Basic Wellness Package", description: "Focused everyday health tracking", price: "999", features: { tests: ["CBC", "Blood Sugar", "Vitamin D", "BMI Assessment"] }, category: "Essential", popular: false },
    ]);

    // ─── Articles / Blog ───
    await db.insert(articles).values([
      { title: "10 Heart-Healthy Habits That Actually Work", slug: "heart-healthy-habits", excerpt: "Simple lifestyle changes that significantly reduce cardiovascular risk.", category: "Cardiology", authorName: "Dr. Arjun Mehta", imageUrl: "", isPublished: true },
      { title: "Understanding Your Blood Sugar Levels", slug: "blood-sugar-guide", excerpt: "What do your glucose readings really mean? A complete guide for diabetics and pre-diabetics.", category: "Diabetes", authorName: "Dr. Suresh Nandakumar", imageUrl: "", isPublished: true },
      { title: "Skin Care Routine by Dermatologists", slug: "dermatologist-skin-care", excerpt: "The evidence-based morning and night routine your skin deserves.", category: "Dermatology", authorName: "Dr. Sneha Reddy", imageUrl: "", isPublished: true },
      { title: "Managing Back Pain: When to See an Orthopedist", slug: "back-pain-orthopedist", excerpt: "From posture fixes to surgery - the complete back pain treatment roadmap.", category: "Orthopedics", authorName: "Dr. Vikram Nair", imageUrl: "", isPublished: true },
      { title: "Child Vaccination Schedule Guide 2024", slug: "child-vaccination-schedule", excerpt: "Every vaccine your child needs and when - a must-read for new parents.", category: "Pediatrics", authorName: "Dr. Nisha Patel", imageUrl: "", isPublished: true },
      { title: "Fasting vs Non-Fasting Blood Tests Decoded", slug: "fasting-tests-guide", excerpt: "Why do some tests require fasting and others don't? Get it right every time.", category: "Lab & Diagnostics", authorName: "MedVerse Labs", imageUrl: "", isPublished: true },
    ]);

    // ─── Appointments ───
    const docs = await db.select().from(doctors);
    const patientsList = await db.select().from(patients);
    const today = new Date().toISOString().split("T")[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0];
    const dayAfter = new Date(Date.now() + 172800000).toISOString().split("T")[0];

    await db.insert(appointments).values([
      {
        bookingId: `APPT-${Date.now()}-2211`,
        patientId: patientsList[0]?.id,
        doctorId: docs[0]?.id,
        hospitalId: hospitalList[0]?.id,
        appointmentDate: today,
        timeSlot: "10:30 AM",
        visitType: "in-person",
        status: "confirmed",
        symptoms: "Chest discomfort on exertion, mild palpitations",
        paymentMethod: "insurance",
        paymentStatus: "paid",
        amount: "1200",
      },
      {
        bookingId: `APPT-${Date.now()}-2212`,
        patientId: patientsList[1]?.id,
        doctorId: docs[3]?.id,
        hospitalId: hospitalList[0]?.id,
        appointmentDate: tomorrow,
        timeSlot: "04:00 PM",
        visitType: "video",
        status: "confirmed",
        symptoms: "Recurrent headaches, occasional numbness",
        paymentMethod: "online",
        paymentStatus: "paid",
        amount: "900",
      },
      {
        bookingId: `APPT-${Date.now()}-2213`,
        patientId: patientsList[0]?.id,
        doctorId: docs[6]?.id,
        hospitalId: hospitalList[0]?.id,
        appointmentDate: dayAfter,
        timeSlot: "11:00 AM",
        visitType: "in-person",
        status: "pending",
        symptoms: "Child fever and cough for 2 days",
        paymentMethod: "hospital",
        paymentStatus: "unpaid",
        amount: "800",
      },
      {
        bookingId: `APPT-${Date.now()}-2214`,
        patientId: patientsList[1]?.id,
        doctorId: docs[1]?.id,
        hospitalId: hospitalList[1]?.id,
        appointmentDate: tomorrow,
        timeSlot: "02:30 PM",
        visitType: "in-person",
        status: "pending",
        symptoms: "Skin rash and itching on both arms",
        paymentMethod: "online",
        paymentStatus: "unpaid",
        amount: "900",
      },
    ]);

    // ─── Invoices ───
    const apptList = await db.select().from(appointments);
    await db.insert(invoices).values([
      {
        invoiceNo: `INV-${Date.now()}-1001`,
        patientId: patientsList[0]?.id,
        appointmentId: apptList[0]?.id,
        type: "consultation",
        description: "Cardiology consultation - Dr. Arjun Mehta",
        amount: "1200",
        tax: "216",
        discount: "100",
        totalAmount: "1316",
        status: "paid",
        paymentMethod: "insurance",
        insuranceClaimed: true,
      },
      {
        invoiceNo: `INV-${Date.now()}-1002`,
        patientId: patientsList[1]?.id,
        appointmentId: apptList[1]?.id,
        type: "consultation",
        description: "Video consultation - Dr. Anjali Gupta",
        amount: "900",
        tax: "162",
        discount: "0",
        totalAmount: "1062",
        status: "paid",
        paymentMethod: "online",
      },
      {
        invoiceNo: `INV-${Date.now()}-1003`,
        patientId: patientsList[0]?.id,
        type: "lab",
        description: "Comprehensive Health Checkup Package",
        amount: "2999",
        tax: "539.82",
        discount: "250",
        totalAmount: "3288.82",
        status: "unpaid",
        paymentMethod: null,
      },
      {
        invoiceNo: `INV-${Date.now()}-1004`,
        patientId: patientsList[1]?.id,
        type: "pharmacy",
        description: "Medicine order - Dolo 650 (2 strip), Cetirizine (1 strip)",
        amount: "145",
        tax: "26.1",
        discount: "10",
        totalAmount: "161.1",
        status: "paid",
        paymentMethod: "online",
      },
    ]);

    // ─── Sample vitals ───
    return new Response(
      JSON.stringify({
        message: "Database seeded successfully",
        stats: {
          hospitals: hospitalList.length,
          departments: deptData.length,
          doctors: docData.length,
          patients: 2,
          medicines: 8,
          labTests: 10,
          healthPackages: 8,
          articles: 6,
          appointments: 4,
          invoices: 4,
        },
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Seed error:", err);
    return new Response(
      JSON.stringify({ message: "Seed failed", error: err instanceof Error ? err.message : String(err) }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}
