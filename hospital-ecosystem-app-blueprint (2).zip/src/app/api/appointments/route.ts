import { NextResponse } from "next/server";
import { db } from "@/db";
import { appointments, patients, doctors, users, hospitals } from "@/db/schema";
import { sql, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const patientId = searchParams.get("patientId");
    const doctorId = searchParams.get("doctorId");
    const status = searchParams.get("status");

    const conditions = [];
    if (patientId) conditions.push(sql`${appointments.patientId} = ${Number(patientId)}`);
    if (doctorId) conditions.push(sql`${appointments.doctorId} = ${Number(doctorId)}`);
    if (status) conditions.push(sql`${appointments.status} = ${status}`);

    const where = conditions.length ? sql.join(conditions, sql` AND `) : sql`1 = 1`;

    const result = await db
      .select({
        id: appointments.id,
        bookingId: appointments.bookingId,
        appointmentDate: appointments.appointmentDate,
        timeSlot: appointments.timeSlot,
        visitType: appointments.visitType,
        status: appointments.status,
        symptoms: appointments.symptoms,
        notes: appointments.notes,
        paymentMethod: appointments.paymentMethod,
        paymentStatus: appointments.paymentStatus,
        amount: appointments.amount,
        createdAt: appointments.createdAt,
        patientId: appointments.patientId,
        doctorId: appointments.doctorId,
        doctorName: users.name,
        doctorSpecialization: doctors.specialization,
        doctorQualifications: doctors.qualifications,
        hospitalName: hospitals.name,
        hospitalCity: hospitals.city,
        patientName: patients.medicalId,
      })
      .from(appointments)
      .leftJoin(patients, sql`${patients.id} = ${appointments.patientId}`)
      .leftJoin(doctors, sql`${doctors.id} = ${appointments.doctorId}`)
      .leftJoin(users, sql`${users.id} = ${doctors.userId}`)
      .leftJoin(hospitals, sql`${hospitals.id} = ${appointments.hospitalId}`)
      .where(where)
      .orderBy(desc(appointments.appointmentDate));

    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    if (!body.patientId || !body.doctorId || !body.appointmentDate || !body.timeSlot) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const bookingId = `APPT-${Date.now()}-${Math.floor(Math.random() * 9999)}`;
    const qrCode = `MV-QR-${bookingId}`;

    const [appt] = await db
      .insert(appointments)
      .values({
        bookingId,
        patientId: Number(body.patientId),
        doctorId: Number(body.doctorId),
        hospitalId: body.hospitalId ? Number(body.hospitalId) : null,
        appointmentDate: body.appointmentDate,
        timeSlot: body.timeSlot,
        visitType: body.visitType ?? "in-person",
        status: "confirmed",
        symptoms: body.symptoms,
        notes: body.notes,
        paymentMethod: body.paymentMethod ?? "hospital",
        paymentStatus: body.paymentStatus ?? "unpaid",
        amount: body.amount,
        qrCode,
      })
      .returning();

    return NextResponse.json({ success: true, appointment: appt }, { status: 201 });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
