import { NextResponse } from "next/server";
import { db } from "@/db";
import { departments, doctors } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const result = await db
      .select({
        id: departments.id,
        name: departments.name,
        code: departments.code,
        description: departments.description,
        icon: departments.icon,
        doctorCount: sql<number>`(select count(*)::int from doctors d where d.department_id = ${departments.id})`,
      })
      .from(departments)
      .where(sql`${departments.isActive} = true`)
      .orderBy(departments.name);

    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
