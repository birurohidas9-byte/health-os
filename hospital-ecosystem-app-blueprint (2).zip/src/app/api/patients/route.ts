import { NextResponse } from "next/server";
import { db } from "@/db";
import { patients, users } from "@/db/schema";
import { sql, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search");

    const result = await db
      .select({
        id: patients.id,
        medicalId: patients.medicalId,
        bloodGroup: patients.bloodGroup,
        dob: patients.dob,
        gender: patients.gender,
        allergies: patients.allergies,
        chronicConditions: patients.chronicConditions,
        insuranceProvider: patients.insuranceProvider,
        insurancePolicyNo: patients.insurancePolicyNo,
        insuranceCoverage: patients.insuranceCoverage,
        city: patients.city,
        state: patients.state,
        abhaId: patients.abhaId,
        createdAt: patients.createdAt,
        name: users.name,
        phone: users.phone,
        email: users.email,
      })
      .from(patients)
      .leftJoin(users, sql`${users.id} = ${patients.userId}`)
      .where(search ? sql`(${users.name} ILIKE ${`%${search}%`} OR ${patients.medicalId} ILIKE ${`%${search}%`})` : sql`1 = 1`)
      .orderBy(desc(patients.createdAt));

    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
