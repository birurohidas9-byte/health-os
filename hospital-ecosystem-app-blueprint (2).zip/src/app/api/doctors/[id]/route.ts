import { NextResponse } from "next/server";
import { db } from "@/db";
import { doctors, users, departments, hospitals, appointments, reviews } from "@/db/schema";
import { sql, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const docId = Number(id);

    const [doctor] = await db
      .select({
        id: doctors.id,
        userId: doctors.userId,
        registrationNo: doctors.registrationNo,
        qualifications: doctors.qualifications,
        specialization: doctors.specialization,
        yearsOfExperience: doctors.yearsOfExperience,
        consultationFee: doctors.consultationFee,
        videoConsultFee: doctors.videoConsultFee,
        rating: doctors.rating,
        ratingCount: doctors.ratingCount,
        bio: doctors.bio,
        languages: doctors.languages,
        availableToday: doctors.availableToday,
        videoConsultAvailable: doctors.videoConsultAvailable,
        homeVisitAvailable: doctors.homeVisitAvailable,
        acceptsInsurance: doctors.acceptsInsurance,
        name: users.name,
        email: users.email,
        phone: users.phone,
        departmentName: departments.name,
        departmentCode: departments.code,
        hospitalName: hospitals.name,
        hospitalCity: hospitals.city,
        hospitalAddress: hospitals.address,
      })
      .from(doctors)
      .leftJoin(users, eq(users.id, doctors.userId))
      .leftJoin(departments, eq(departments.id, doctors.departmentId))
      .leftJoin(hospitals, eq(hospitals.id, doctors.hospitalId))
      .where(eq(doctors.id, docId));

    if (!doctor) {
      return NextResponse.json({ error: "Doctor not found" }, { status: 404 });
    }

    const upcomingAppointments = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(appointments)
      .where(sql`${appointments.doctorId} = ${docId} AND ${appointments.appointmentDate} >= CURRENT_DATE`);

    const doctorReviews = await db
      .select({
        id: reviews.id,
        rating: reviews.rating,
        comment: reviews.comment,
        createdAt: reviews.createdAt,
      })
      .from(reviews)
      .where(eq(reviews.doctorId, docId))
      .orderBy(desc(reviews.createdAt))
      .limit(10);

    return NextResponse.json({
      ...doctor,
      upcomingAppointments: upcomingAppointments[0]?.count ?? 0,
      reviews: doctorReviews,
      availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM", "06:00 PM"],
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
