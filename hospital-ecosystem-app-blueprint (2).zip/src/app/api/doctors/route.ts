import { NextResponse } from "next/server";
import { db } from "@/db";
import { doctors, users, departments, hospitals } from "@/db/schema";
import { desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const spec = searchParams.get("specialization");
    const specialty = searchParams.get("specialty");

    const filter = spec ?? specialty;

    let conditions = sql`1 = 1`;
    if (filter) {
      conditions = sql`(${doctors.specialization} ILIKE ${`%${filter}%`} OR ${doctors.specialization} ILIKE ${`%${filter}%`})`;
    }

    const result = await db
      .select({
        id: doctors.id,
        userId: doctors.userId,
        registrationNo: doctors.registrationNo,
        qualifications: doctors.qualifications,
        specialization: doctors.specialization,
        yearsOfExperience: doctors.yearsOfExperience,
        consultationFee: doctors.consultationFee,
        videoConsultFee: doctors.videoConsultFee,
        rating: doctors.rating,
        ratingCount: doctors.ratingCount,
        bio: doctors.bio,
        languages: doctors.languages,
        availableToday: doctors.availableToday,
        videoConsultAvailable: doctors.videoConsultAvailable,
        homeVisitAvailable: doctors.homeVisitAvailable,
        acceptsInsurance: doctors.acceptsInsurance,
        name: users.name,
        email: users.email,
        phone: users.phone,
        departmentName: departments.name,
        departmentCode: departments.code,
        hospitalName: hospitals.name,
        hospitalCity: hospitals.city,
      })
      .from(doctors)
      .leftJoin(users, sql`${users.id} = ${doctors.userId}`)
      .leftJoin(departments, sql`${departments.id} = ${doctors.departmentId}`)
      .leftJoin(hospitals, sql`${hospitals.id} = ${doctors.hospitalId}`)
      .where(conditions)
      .orderBy(desc(doctors.rating));

    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
