import { NextResponse } from "next/server";
import { db } from "@/db";
import { labTests } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search");

    const result = await db
      .select()
      .from(labTests)
      .where(
        search
          ? sql`(${labTests.name} ILIKE ${`%${search}%`} OR ${labTests.category} ILIKE ${`%${search}%`})`
          : sql`1 = 1`
      )
      .orderBy(labTests.category);

    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
