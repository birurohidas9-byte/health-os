import { NextResponse } from "next/server";
import { db } from "@/db";
import { medicines } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search");

    const result = await db
      .select()
      .from(medicines)
      .where(
        search
          ? sql`(${medicines.name} ILIKE ${`%${search}%`} OR ${medicines.brand} ILIKE ${`%${search}%`} OR ${medicines.genericName} ILIKE ${`%${search}%`})`
          : sql`1 = 1`
      )
      .orderBy(medicines.name);

    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
