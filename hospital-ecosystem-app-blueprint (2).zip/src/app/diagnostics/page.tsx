"use client";

import { useEffect, useMemo, useState } from "react";
import Navbar from "@/components/Navbar";
import { IconSearch, IconTestTube, IconPlus, IconHome } from "@/components/icons";

interface LabTest {
  id: number;
  name: string;
  code: string;
  category: string;
  price: string;
  homeCollection: boolean;
  preparationInstructions: string;
  normalRange: string;
  turnaroundTime: string;
}

export default function DiagnosticsPage() {
  const [tests, setTests] = useState<LabTest[]>([]);
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [loading, setLoading] = useState(true);
  const [booked, setBooked] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/lab-tests");
        setTests(await res.json());
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const categories = useMemo(() => [...new Set(tests.map((t) => t.category))], [tests]);

  const filtered = useMemo(() => {
    return tests.filter((t) => {
      const matchesSearch =
        !search || t.name.toLowerCase().includes(search.toLowerCase()) || t.category.toLowerCase().includes(search.toLowerCase());
      const matchesCat = !selectedCategory || t.category === selectedCategory;
      return matchesSearch && matchesCat;
    });
  }, [tests, search, selectedCategory]);

  const total = filtered.reduce((sum, t) => sum + Number(t.price), 0);

  if (booked) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="mx-auto max-w-lg px-4 py-20 text-center sm:px-6">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500 text-white">
            <IconHome className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Sample Collection Booked!</h1>
          <p className="mt-3 text-slate-600">Our phlebotomist will reach your home. Reports will be available in your patient portal within 24 hours.</p>
          <button onClick={() => setBooked(false)} className="mt-6 rounded-lg bg-teal-600 px-6 py-2.5 text-sm font-semibold text-white">Book Another Test</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <section className="border-b border-slate-200 bg-gradient-to-br from-purple-50 to-white py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold tracking-tight text-slate-900">Lab Tests & Health Checkups</h1>
          <p className="mt-3 max-w-xl text-lg text-slate-600">
            Book lab tests with FREE home sample collection. Get digital reports with smart visualizations.
          </p>
          <div className="mt-8 flex max-w-lg items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
            <IconSearch className="h-5 w-5 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search tests, e.g. 'lipid profile'..."
              className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
            />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedCategory("")}
            className={`rounded-full px-4 py-1.5 text-sm font-medium ${
              selectedCategory === "" ? "bg-purple-600 text-white" : "border border-slate-200 bg-white text-slate-600"
            }`}
          >
            All Tests
          </button>
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setSelectedCategory(selectedCategory === c ? "" : c)}
              className={`rounded-full px-4 py-1.5 text-sm font-medium ${
                selectedCategory === c ? "bg-purple-600 text-white" : "border border-slate-200 bg-white text-slate-600"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => <div key={i} className="h-36 animate-pulse rounded-xl bg-slate-100" />)}
          </div>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filtered.map((test) => (
                <div key={test.id} className="flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-shadow hover:shadow-md">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-50 text-purple-600">
                        <IconTestTube className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">{test.name}</h3>
                        <p className="text-xs text-slate-500">{test.category} · {test.code}</p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center gap-2 text-xs">
                    {test.homeCollection && (
                      <span className="rounded-full bg-purple-50 px-2 py-0.5 font-medium text-purple-600">Home collection</span>
                    )}
                    <span className="text-slate-400">TAT: {test.turnaroundTime}</span>
                  </div>
                  <p className="mt-2 text-xs text-slate-500">{test.preparationInstructions}</p>
                  <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
                    <p className="text-lg font-bold text-slate-900">₹{test.price}</p>
                    <button
                      onClick={() => setBooked(true)}
                      className="inline-flex items-center gap-1 rounded-lg bg-purple-600 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-purple-700"
                    >
                      <IconPlus className="h-3.5 w-3.5" /> Book Now
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Health checkup packages */}
            <div className="mt-12">
              <h2 className="text-2xl font-bold text-slate-900">Health Checkup Packages</h2>
              <p className="mt-2 text-slate-600">Comprehensive screening designed for every age and need.</p>
              <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {[
                  { name: "Basic Health Checkup", price: "1,499", label: "Popular", desc: "CBC · Blood Sugar · Lipid Profile", color: "from-teal-500 to-emerald-600" },
                  { name: "Comprehensive Checkup", price: "2,999", label: "Best Value", desc: "Full blood panel + Thyroid + Vitamin D", color: "from-blue-500 to-indigo-600" },
                  { name: "Executive Checkup", price: "5,999", label: "Premium", desc: "Advanced cardiac + cancer markers + imaging", color: "from-purple-500 to-fuchsia-600" },
                  { name: "Women's Health", price: "3,999", label: "For Her", desc: "Mammogram + Pap + hormone panel", color: "from-pink-500 to-rose-600" },
                  { name: "Cardiac Care", price: "4,999", label: "Heart Focus", desc: "Echo + TMT + lipid + cardiac markers", color: "from-red-500 to-rose-600" },
                  { name: "Diabetes Care", price: "2,499", label: "For Diabetics", desc: "HbA1c + kidney function + microalbumin", color: "from-amber-500 to-orange-600" },
                ].map((pkg) => (
                  <button key={pkg.name} onClick={() => setBooked(true)} className="group relative overflow-hidden rounded-2xl text-left shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg">
                    <div className={`bg-gradient-to-br ${pkg.color} p-6`}>
                      <span className="absolute right-4 top-4 rounded-full bg-white/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">{pkg.label}</span>
                      <h3 className="text-lg font-bold text-white">{pkg.name}</h3>
                      <p className="mt-1 text-sm text-white/80">{pkg.desc}</p>
                      <p className="mt-4 text-2xl font-bold text-white">₹{pkg.price}</p>
                      <p className="text-xs text-white/60">One-time · home collection · reports in 24h</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
