import Navbar from "@/components/Navbar";
import Link from "next/link";
import {
  IconCalendar,
  IconStethoscope,
  IconPill,
  IconTestTube,
  IconAmbulance,
  IconUser,
  IconShield,
  IconVideo,
  IconSparkles,
  IconHeartPulse,
  IconArrowRight,
} from "@/components/icons";

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-teal-700 via-teal-800 to-emerald-900" />
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 20% 50%, rgba(255,255,255,0.3) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(255,255,255,0.2) 0%, transparent 40%)" }} />
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="max-w-3xl">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-teal-300/40 bg-teal-400/10 px-4 py-1.5 text-sm font-medium text-teal-100">
              <IconSparkles className="h-4 w-4" />
              Apollo-grade comprehensive hospital ecosystem
            </div>
            <h1 className="text-4xl font-bold leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
              Your Complete<br />
              <span className="text-teal-300">Hospital Experience</span>,<br />
              All in One Place.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-teal-50/90">
              Book appointments with trusted doctors, order medicines, schedule lab tests,
              and manage your entire family's health records — across multiple hospital
              branches. Hospital-class care, at your fingertips.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                href="/doctors"
                className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 text-sm font-semibold text-teal-800 shadow-lg shadow-emerald-900/30 transition-transform hover:scale-[1.02]"
              >
                <IconStethoscope className="h-5 w-5" />
                Find a Doctor
              </Link>
              <Link
                href="/appointment/new"
                className="inline-flex items-center gap-2 rounded-xl border border-white/30 bg-white/10 px-6 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-colors hover:bg-white/20"
              >
                <IconCalendar className="h-5 w-5" />
                Book Appointment
              </Link>
              <Link
                href="/emergency"
                className="inline-flex items-center gap-2 rounded-xl bg-red-500/90 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-red-900/30 transition-transform hover:scale-[1.02]"
              >
                <IconAmbulance className="h-5 w-5" />
                24×7 Emergency
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap items-center gap-8 text-sm text-teal-100/80">
              <div><span className="text-2xl font-bold text-white">450+</span> Beds</div>
              <div><span className="text-2xl font-bold text-white">100+</span> Specialists</div>
              <div><span className="text-2xl font-bold text-white">15+</span> Specialities</div>
              <div><span className="text-2xl font-bold text-white">24×7</span> Emergency Care</div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-10 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Everything You Need. One Ecosystem.</h2>
          <p className="mt-3 text-slate-600">From symptom to recovery — MedVerse connects every part of your healthcare journey.</p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: IconStethoscope, title: "Expert Doctors", desc: "100+ specialists across 15+ departments with verified credentials", color: "from-teal-500 to-emerald-500", href: "/doctors" },
            { icon: IconVideo, title: "Video Consult", desc: "Consult from home with HD telemedicine appointments", color: "from-blue-500 to-indigo-500", href: "/doctors" },
            { icon: IconPill, title: "Pharmacy", desc: "Order medicines with doorstep delivery & reminders", color: "from-amber-500 to-orange-500", href: "/pharmacy" },
            { icon: IconTestTube, title: "Lab Diagnostics", desc: "Book tests with home sample collection", color: "from-purple-500 to-fuchsia-500", href: "/diagnostics" },
            { icon: IconHeartPulse, title: "Health Checkups", desc: "Screening packages tailored to every age group", color: "from-rose-500 to-red-500", href: "/diagnostics" },
            { icon: IconAmbulance, title: "Emergency / SOS", desc: "One-tap emergency dispatch with live tracking", color: "from-red-500 to-rose-600", href: "/emergency" },
            { icon: IconUser, title: "Family Records", desc: "Unified PHR for your whole family, always accessible", color: "from-cyan-500 to-sky-500", href: "/patient" },
            { icon: IconShield, title: "Insurance Support", desc: "Cashless claims & pre-authorization tracking", color: "from-emerald-500 to-green-600", href: "/patient" },
          ].map((item) => (
            <Link
              key={item.title}
              href={item.href}
              className="group rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg"
            >
              <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${item.color} text-white shadow-md`}>
                <item.icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">{item.desc}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Departments */}
      <section className="border-y border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-slate-900">World-Class Departments</h2>
              <p className="mt-3 text-slate-600">Advanced centers of excellence staffed by leading specialists.</p>
            </div>
            <Link href="/doctors" className="inline-flex items-center gap-1.5 text-sm font-semibold text-teal-600 hover:text-teal-700">
              View all doctors <IconArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { name: "Cardiology", desc: "Heart & vascular care", emoji: "🫀" },
              { name: "Neurology", desc: "Brain & spine", emoji: "🧠" },
              { name: "Orthopedics", desc: "Bones & joints", emoji: "🦴" },
              { name: "Oncology", desc: "Cancer care", emoji: "🎗️" },
              { name: "Gynecology", desc: "Women's health", emoji: "🌸" },
              { name: "Pediatrics", desc: "Child health", emoji: "👶" },
              { name: "Dermatology", desc: "Skin & hair", emoji: "✨" },
              { name: "Gastroenterology", desc: "Digestive health", emoji: "🫗" },
              { name: "Endocrinology", desc: "Hormone health", emoji: "💉" },
              { name: "Pulmonology", desc: "Lung health", emoji: "🫁" },
              { name: "Ophthalmology", desc: "Eye care", emoji: "👁️" },
              { name: "Physiotherapy", desc: "Rehab & recovery", emoji: "🦵" },
            ].map((dept) => (
              <Link key={dept.name} href={`/doctors?specialty=${dept.name}`} className="group flex items-center gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4 transition-all hover:border-teal-200 hover:bg-teal-50">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white text-2xl shadow-sm">{dept.emoji}</div>
                <div>
                  <h3 className="font-semibold text-slate-900 group-hover:text-teal-700">{dept.name}</h3>
                  <p className="text-sm text-slate-500">{dept.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-10 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Care in 3 Simple Steps</h2>
          <p className="mt-3 text-slate-600">Designed around patients, not paperwork.</p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { step: "01", title: "Choose Your Doctor", desc: "Search by specialty, symptom, or name. Compare experience, fees, and ratings.", color: "text-teal-600" },
            { step: "02", title: "Book & Pay", desc: "Pick a time slot, choose in-person or video visit, and pay securely or go cashless.", color: "text-blue-600" },
            { step: "03", title: "Get Treated", desc: "Hospital check-in is seamless. Get digital prescriptions, lab orders, and follow-ups.", color: "text-emerald-600" },
          ].map((step) => (
            <div key={step.step} className="relative rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
              <div className={`mx-auto mb-4 text-5xl font-bold ${step.color}`}>{step.step}</div>
              <h3 className="text-xl font-semibold text-slate-900">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-br from-teal-700 via-teal-800 to-emerald-900 py-16">
        <div className="mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">Ready to Get the Care You Deserve?</h2>
          <p className="mx-auto mt-4 max-w-2xl text-teal-100/90">
            Join thousands of patients who trust MedVerse for their family's health.
            Manage appointments, records, and medicines from anywhere.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link href="/doctors" className="rounded-xl bg-white px-8 py-3.5 text-sm font-semibold text-teal-800 shadow-lg transition-transform hover:scale-[1.02]">
              Get Started Now
            </Link>
            <Link href="/admin" className="rounded-xl border border-white/30 bg-white/10 px-8 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-colors hover:bg-white/20">
              Explore Admin Dashboard
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-4">
            <div>
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-teal-600 to-emerald-500">
                  <svg viewBox="0 0 24 24" className="h-4 w-4 text-white" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M3 12h3l2-5 3 9 2.5-6L15 12h6" /></svg>
                </div>
                <span className="text-lg font-bold text-slate-900">Med<span className="text-teal-600">Verse</span></span>
              </div>
              <p className="mt-4 text-sm text-slate-500">World-class hospital care, digitized. Trusted by patients across India.</p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900">Patient Care</h4>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                <li><Link href="/doctors" className="hover:text-teal-600">Find a Doctor</Link></li>
                <li><Link href="/pharmacy" className="hover:text-teal-600">Order Medicines</Link></li>
                <li><Link href="/diagnostics" className="hover:text-teal-600">Book Lab Test</Link></li>
                <li><Link href="/emergency" className="hover:text-teal-600">Emergency / SOS</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900">Our Hospitals</h4>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                <li><Link href="/hospitals" className="hover:text-teal-600">Bengaluru</Link></li>
                <li><Link href="/hospitals" className="hover:text-teal-600">Delhi NCR</Link></li>
                <li><Link href="/hospitals" className="hover:text-teal-600">Mumbai</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900">Support</h4>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                <li>24×7 Helpline: 1800 200 1100</li>
                <li>Email: care@medverse.in</li>
                <li>Ambulance: 102</li>
              </ul>
            </div>
          </div>
          <div className="mt-10 border-t border-slate-200 pt-6 text-center text-sm text-slate-400">
            © 2026 MedVerse Health Systems. All rights reserved. Apollo-grade hospital ecosystem demo.
          </div>
        </div>
      </footer>
    </div>
  );
}
