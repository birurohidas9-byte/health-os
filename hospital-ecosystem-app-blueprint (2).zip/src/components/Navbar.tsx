"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { IconBell, IconMenu, IconPlus, IconSearch, IconX } from "./icons";
import { useState } from "react";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/hospitals", label: "Hospitals" },
  { href: "/doctors", label: "Find Doctors" },
  { href: "/pharmacy", label: "Pharmacy" },
  { href: "/diagnostics", label: "Diagnostics" },
  { href: "/patient", label: "Patient Portal" },
  { href: "/admin", label: "Admin" },
];

export default function Navbar() {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-600 to-emerald-500 shadow-md shadow-emerald-200">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 12h3l2-5 3 9 2.5-6L15 12h6" />
            </svg>
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-lg font-bold tracking-tight text-slate-900">Med<span className="text-teal-600">Verse</span></span>
            <span className="text-[10px] font-medium uppercase tracking-widest text-slate-400">Hospital Ecosystem</span>
          </div>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 lg:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                pathname === link.href
                  ? "bg-teal-50 text-teal-700"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <button className="hidden rounded-lg border border-slate-200 p-2 text-slate-500 transition-colors hover:bg-slate-100 sm:block">
            <IconSearch className="h-5 w-5" />
          </button>
          <button className="relative hidden rounded-lg border border-slate-200 p-2 text-slate-500 transition-colors hover:bg-slate-100 sm:block">
            <IconBell className="h-5 w-5" />
            <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white">3</span>
          </button>
          <Link
            href="/appointment/new"
            className="hidden items-center gap-1.5 rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white shadow-sm shadow-teal-200 transition-colors hover:bg-teal-700 sm:flex"
          >
            <IconPlus className="h-4 w-4" /> Book Appointment
          </Link>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="rounded-lg border border-slate-200 p-2 text-slate-600 lg:hidden"
          >
            {menuOpen ? <IconX className="h-5 w-5" /> : <IconMenu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="border-t border-slate-100 bg-white lg:hidden">
          <div className="space-y-1 px-4 py-4">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className={`block rounded-lg px-3 py-2.5 text-sm font-medium ${
                  pathname === link.href ? "bg-teal-50 text-teal-700" : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/appointment/new"
              onClick={() => setMenuOpen(false)}
              className="mt-2 flex items-center justify-center gap-1.5 rounded-lg bg-teal-600 px-4 py-2.5 text-sm font-semibold text-white"
            >
              <IconPlus className="h-4 w-4" /> Book Appointment
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
